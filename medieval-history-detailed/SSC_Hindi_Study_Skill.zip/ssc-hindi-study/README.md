# SSC Hindi Study Skill

स्कैन से **पूरा मूल अनुवाद** बनाए रखें और उसके साथ **अलग, विस्तृत हिंदी अध्ययन-पाठ** जोड़ें। एक बार में एक मुद्रित पृष्ठ या एक PYQ विषय लें। यह फ़ाइल-आधारित स्किल है: `SKILL.md` एजेंट के लिए निर्देश है, `skill.py` इकाइयों को जाँचने और जोड़ने का प्रोग्राम है। स्क्रिप्ट खुद इतिहास नहीं लिखती, चित्र नहीं पढ़ती और तथ्य सत्यापित नहीं करती।

## इसे मध्यकालीन इतिहास पर कैसे चलाया गया

| इकाइयाँ | परिणाम |
|---|---:|
| 9 सिद्धांत पृष्ठ, 22–30 | 146/146 स्रोत-पंक्तियाँ व्याख्या से जुड़ीं, 46 अध्ययन अनुभाग |
| 3 मूल अभ्यास पृष्ठ, 31–33 | 48 प्रश्न: पुस्तक की कुंजी, उत्तर का कारण और भटकाने वाले विकल्प से फर्क |
| 5 PYQ समूह | 42 प्रश्न: संकलन की कुंजी, तारीख़, शिफ़्ट, क्रमांक, ID, PDF पृष्ठ और हल |

`examples/medieval-case/` में 17 इकाइयों की मूल ट्रांसक्रिप्शन, विस्तार, संदर्भ, `run-log.txt`, `coverage.json`, अनुमोदित इकाइयाँ और `compiled.json` हैं। ये स्कैन तुलना के बाद बने हैं। 16 स्रोत-नोट मूल कथन, संकलन की कुंजी और ऐतिहासिक स्पष्टीकरण को अलग रखते हैं। यह परीक्षा की आधिकारिक अंतिम कुंजी नहीं है।

## अगले अध्याय पर

1. `SKILL.md` और `FORMAT.md` पढ़ें। `manifest.example.json` की कॉपी बनाकर अध्याय का पृष्ठ-दायरा, स्कैन और ट्रांसक्रिप्शन की फ़ाइलें चुनें। PYQ न हों तो `bank_json` और `bank_pdf` को `null` रखें; मूल अभ्यास न हो तो `practice_first` हटाएँ।
2. Python 3.11+ में `python -m pip install -r requirements.txt` चलाएँ।
3. `list` से इकाइयाँ देखें। नीचे पृ. 22 का उदाहरण है; अपने अध्याय में सूची से इकाई चुनें।

```sh
python skill.py --manifest examples/medieval-case/manifest.json list
python skill.py --manifest examples/medieval-case/manifest.json prepare p-22
# स्कैन और लाइन-सूची पढ़ें, notes/p-22.txt में व्याख्या सुधारें या लिखें।
python skill.py --manifest examples/medieval-case/manifest.json check p-22
# स्रोत से मैनुअल मिलान के बाद ही:
python skill.py --manifest examples/medieval-case/manifest.json check p-22 --reviewed
# सभी इकाइयों के बाद:
python skill.py --manifest examples/medieval-case/manifest.json assemble
```

इसी क्रम को हर इकाई पर दोहराएँ। बिना समीक्षा, गायब व्याख्या, बदले स्रोत या पुराने अनुमोदन पर `assemble` रुकता है। उदाहरण के नए स्कैन मिलान के लिए `examples/medieval-case/sources/README.md` देखें।

## शामिल मध्यकालीन उदाहरण फिर से बनाएँ

प्रकाशित HTML व PDF पढ़ने के लिए इंस्टॉलेशन नहीं चाहिए। अगर उदाहरण को फिर बनाना हो, तो इसके जाँचे गए `compiled.json` से सीधे बनाएँ; इस चरण के लिए मूल PDF दोबारा नहीं चाहिए। Linux/macOS उदाहरण (Windows पर WSL, या इन्हीं Python/Node स्क्रिप्टों के लिए `STUDY_*` पथ सेट करें):

```sh
python -m pip install -r requirements.txt
sh rebuild.sh --html
```

`exports/index.html` ही ऑफलाइन पेज है। इसे GitHub Pages की प्रकाशन फ़ोल्डर में `index.html` के रूप में रखा जा सकता है। उसका मुख्य पाठ, चित्र, फ़ॉन्ट और खोज बाहरी CDN नहीं माँगते; बाहरी संदर्भ खोलने के लिए इंटरनेट चाहिए। PDF भी फिर बनाना हो तो Node.js 22+ और Chromium रखें:

```sh
cd renderer
npm install
npx playwright-core install chromium
cd ..
sh rebuild.sh --all
```

जरूरत हो तो `CHROMIUM` में अपनी Chromium binary का पथ दें। Chromium की Linux system libraries भी स्थापित हों। `renderer/` का लेआउट और QA मध्यकालीन उदाहरण के लिए हैं; नए अध्याय में नया लेआउट जाँचें। अलग ब्राउज़र संस्करण पेज-ब्रेक बदल सकते हैं।

**प्रकाशित संस्करण का श्रेय:** Writer: Sonu Shakya
