---
name: ssc-hindi-study
description: Turn a scanned SSC chapter and a sourced PYQ bank into a detailed Hindi study edition without losing original wording, question keys, diagrams or page references. Invoke one unit at a time, review against the scan, and validate before assembly.
---

# SSC Hindi Study Edition

## Inputs

- Scan PDF, printed page range, and the physical-page offset. Locate the chapter boundary from the scan, not from OCR alone.
- One UTF-8 structured transcription per printed page and (optional) a topic-grouped PYQ JSON with all option texts, original keys and locators. If no transcription is available, build it by visually reading one page at a time. Do not feed a summary back in as the source.
- A project manifest modeled on `manifest.example.json`. See `FORMAT.md`. Install the optional scan dependencies from `requirements.txt` if a fresh workspace needs them.

## Invoke repeatedly — one printed page or one PYQ topic at a time

1. **Prepare.** Run `python skill.py --manifest MANIFEST prepare UNIT`. `p-22` is one printed page; `bank-delhi` is one bank topic. Open the generated scan and line inventory, or the bank witness and question list. The raw image is extracted when the page is a single scan, so a white overlay does not hide content. The command records input hashes and line IDs; it does not translate or approve anything. For low-resolution type, use the full resolution image and crop the particular region.
2. **Compare.** Read headings, bullets, child bullets, labels, timeline nodes, table cells, portraits, and MCQ stems/options/answer strips in order. Preserve source irregularities that affect meaning. Only change the source transcript when the source itself justifies the change, then run `prepare` again. Keep the source layer and new notes visibly separate. Unreadable or disputed facts go in a labeled note, not an invented original line.
3. **Explain.** Write a new unit under `notes/`. For theory, explain the *why* or the distinction behind each source block; attach every substantive source line to at least one explanation section. Use examples, timelines, comparisons, definitions and exam traps where they aid understanding, not as filler. Cite the source anchors, verify factual additions with reliable references, and distinguish contested attributions. For practice and PYQs, explain every keyed answer and why a plausible distractor is wrong. For a flawed item, preserve the compilation key and isolate the historical correction. A solution returning only a letter is not a solution.
4. **Check.** Run `python skill.py --manifest MANIFEST check UNIT`. Review failures, revise this unit, and run it again. Only after personally comparing the relevant scan and text, run `check UNIT --reviewed`. That switch attests to a manual comparison; the script itself measures coverage, checks identity/options/key integrity and content structure, and does not claim to verify history or read images.
5. **Repeat.** Do not move to the next chapter by silently shortening a unit. Repeat steps 1–4 separately for each printed page and each PYQ topic. Read continuation questions with the same topic and numbering across page boundaries.
6. **Assemble and inspect.** `python skill.py --manifest MANIFEST assemble` fails on missing units, missing reviews or stale hashes and creates structured `compiled.json` and `coverage.json`. A layout renderer consumes these. Build the final reader and A4 PDF from the same data. Verify every original heading/option/key, all locators, every solution, mobile/offline/print navigation and pagination. Visually inspect representative pages; do not publish overflow or claim official answers for a compilation.

## Expected output

- Original Hindi translation, maintaining the source order, full options, figures/tables and source-page labels.
- Separate, linked detailed Hindi notes, question explanations and factual cautions. Questions and answer keys remain traceable to the book or shared PYQ compilation.
- PDF and standalone HTML when requested; original author credit remains as directed. Keep a per-unit run record for reproducibility.

This is a file-based skill and Python runner; it is not a claim that a native Arena skill has been installed or that one command generates expert prose without review.
