# स्कैन वापस लगाना हो तो

इन दो PDF की पूरी प्रतियाँ ZIP में नहीं हैं। `../compiled.json` पहले से जाँचा हुआ अध्ययन डेटा है। उसी से `rebuild.sh` HTML/PDF फिर से बना सकता है। नए स्कैन मिलान (`prepare` और `assemble`) के लिए PDF नीचे दिए नामों से यहाँ रखें, या `../manifest.json` में उनके पथ बदलें।

| फ़ाइल का नाम | इस्तेमाल किया गया संस्करण |
|---|---|
| `SSC_CGL_General_Awareness_Compressed.pdf` | पहले साझा किया गया 223-पृष्ठ का स्कैन; पुस्तक पृ. 22–33 = PDF पृ. 26–37। |
| `SSC_CGL_Tier1_2026_Compilation.pdf` | [साझा 209-पृष्ठ का PYQ संकलन](https://drive.google.com/file/d/1JENBgfzHjJOWzjafeXRWRMW8KmJXIvi9/view); इसमें दिखाई देने वाली प्रश्न-संख्या और टेक्स्ट की ID अलग हो सकती हैं। |

पहले से जाँची गई इकाइयों का `assemble` तभी सफल होगा जब दोनों PDF पुरानी प्रतियों से बाइट-स्तर पर मिलें। दूसरी कॉपी लें तो उसके विरुद्ध फिर से समीक्षा करें। नीचे पहले इस्तेमाल किए गए SHA-256 हैं:

```text
cb75eeff87b292dd55c69a6dffc62fd0334fe8ed6ea56f9a2a88daa43fb67192  SSC_CGL_General_Awareness_Compressed.pdf
2afae75c39d076e3094bbe1bf7d631343ba77e089dbcfa63b60c988a7a6f2996  SSC_CGL_Tier1_2026_Compilation.pdf
```
