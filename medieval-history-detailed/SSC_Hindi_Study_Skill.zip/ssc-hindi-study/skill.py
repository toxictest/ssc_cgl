#!/usr/bin/env python3
"""Reusable, scan-first authoring runner. Does not generate or certify historical prose."""
import argparse
import hashlib
import io
import json
import re
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


def require(ok, message):
    if not ok:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.writing')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(path)


def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def digest_obj(data):
    return hashlib.sha256(json.dumps(data, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def lines(path):
    return [(i, [a.strip() for a in v.strip().split('|')]) for i,v in enumerate(path.read_text(encoding='utf-8').splitlines(),1) if v.strip()]


def meaningful(s):
    return sum(any('\u0900' <= c <= '\u097f' for c in w) for w in s.split())


def slug(s):
    return re.fullmatch(r'[a-z][a-z0-9-]*', s) is not None


class Project:
    def __init__(self, manifest):
        self.cfg = load(manifest)
        def _path(k):
            v = self.cfg.get(k)
            return (manifest.parent / v).resolve() if v else None
        self.file = _path
        self.books, self.bank_pdf = _path('book_pdf'), _path('bank_pdf')
        self.refs = load(_path('references')) if _path('references') else {}
        for key, ref in self.refs.items():
            require(slug(key) and ref['title'] and ref['url'].startswith('https://'), f'Invalid reference {key}')
        self.topic_ids = self.cfg.get('practice_topics', {})
        self.pages = {}
        self.practice = {}
        self.groups = {}
        bytopic, keys, fallback_topics = {}, {}, {}
        subject = None
        for p in range(self.cfg['first'], self.cfg['last'] + 1):
            f = _path('data') / f'{p:02}.txt'
            (i, head), *rows = lines(f)
            require(len(head)==5 and head[0]=='#' and int(head[1])==p, f'Invalid source header {f}')
            self.pages[p] = {'n':p,'title':head[2],'group':head[3],'chapter':head[4],'lines':[r for _,r in rows], 'indexed':rows}
            if p < self.cfg.get('practice_first', self.cfg['last']+1):
                continue
            self.practice[p] = []
            for i, r in rows:
                if r[0] == 'S':
                    title = r[1]
                    subject = r[2] if len(r) == 3 else self.topic_ids.get(title)
                    if not subject:
                        subject = fallback_topics.setdefault(title, f'topic-{len(fallback_topics)+1}')
                    require(slug(subject), f'Invalid topic slug {subject}')
                    bytopic.setdefault(subject, {})
                elif r[0] == 'Q':
                    require(subject and len(r) in (8,9), f'Invalid Q in {f}:{i}')
                    number = int(r[1]); letters = r[8] if len(r)==9 else 'abcd'
                    require(sorted(letters)==list('abcd') and all(r[3:8]), f'Invalid choices in {f}:{i}')
                    require(number not in bytopic[subject], f'Duplicate {subject}/{number}')
                    q = dict(id=f'{subject}/{number}', number=number, title=title, topic=subject, stamp=r[2], question=r[3], options=r[4:8], letters=letters, page=p, line=i)
                    self.practice[p].append(q); bytopic[subject][number] = q
                elif r[0] == 'K':
                    require(subject and subject not in keys and len(r)>2, f'Invalid key at {f}:{i}')
                    pairs=[re.fullmatch(r'(\d+)\.\s*\(([abcd])\)', v) for v in r[2:]]
                    require(all(pairs), f'Bad answers at {f}:{i}')
                    keys[subject] = {int(m[1]):m[2] for m in pairs}
                    require(len(keys[subject])==len(pairs), f'Duplicate key at {f}:{i}')
                else:
                    require(r[0] in ('X','Y'), f'Unexpected practice row at {f}:{i}')
        require(bytopic.keys()==keys.keys(), 'An original topic has no printed key')
        for t, items in bytopic.items():
            require(items.keys()==keys[t].keys(), f'Question/key mismatch: {t}')
            for n,q in items.items():
                q['key']=keys[t][n]; q['valid_option']=q['options'][q['letters'].index(q['key'])]
        n_seen, s_seen = set(), set()
        if self.file('bank_json'):
            for g in load(self.file('bank_json')):
                require(slug(g['id']) and g['id'] not in self.groups and g['items'], f'Invalid bank group {g["id"]}')
                for q in g['items']:
                    n,s=q['n'],q['serial']; opts=q['options'];k=q['key']
                    require(n not in n_seen and s not in s_seen and isinstance(n,int) and isinstance(s,int) and n>0 and s>0 and q['p']>0 and q['shift_title'] and q['question'] and len(opts)==4 and all(opts) and k in 'ABCD' and len(k)==1, f'Invalid/duplicated bank item {n}')
                    n_seen.add(n); s_seen.add(s)
                self.groups[g['id']]=g
        self.units=[f'p-{p}' for p in self.pages]+[f'bank-{g}' for g in self.groups]

    def unit(self, key):
        require(key in self.units, f'Unknown unit {key}')
        if key.startswith('p-'):
            p=int(key[2:]); src=self.pages[p]
            mode='practice' if p in self.practice else 'theory'
            return mode, {'source':src, 'physical_page':p+self.cfg['physical_offset'], 'questions':self.practice.get(p,[])}
        group=self.groups[key[5:]]
        return 'bank', {'group':group, 'questions':group['items']}

    def fingerprint(self, mode, unit):
        f=self.bank_pdf if mode=='bank' else self.books
        require(f and f.is_file(), f'Missing witness PDF: {f}')
        return {'data_sha256':digest_obj(unit), 'witness_pdf_sha256':digest(f), 'references_sha256':digest_obj(self.refs)}

    def prepare(self, key):
        import pymupdf as fitz
        from PIL import Image
        mode, unit = self.unit(key)
        root = self.file('scratch') / key
        root.mkdir(parents=True, exist_ok=True)
        evidence = self.fingerprint(mode, unit)
        results = []
        if mode!='bank':
            with fitz.open(self.books) as pdf:
                page=pdf[unit['physical_page']-1]
                img=page.get_image_info(xrefs=True)
                if len(img)==1 and img[0]['xref']:
                    r=img[0]; data=pdf.extract_image(r['xref'])['image']; im=Image.open(io.BytesIO(data)).convert('RGB')
                    evidence['raw_image_sha256']=hashlib.sha256(data).hexdigest(); evidence['xref']=r['xref']
                else:
                    pix=page.get_pixmap(matrix=fitz.Matrix(2.8,2.8),alpha=False); im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
                im.save(root/'scan.jpg',quality=95,subsampling=0)
                results.append(str(root/'scan.jpg'))
                for suffix, box in [('upper',(0,0,1,0.55)),('lower',(0,.45,1,1))]:
                    im.crop(tuple(int(c*(im.width if i%2==0 else im.height)) for i,c in enumerate(box))).save(root/f'{suffix}.jpg',quality=96,subsampling=0)
        else:
            with fitz.open(self.bank_pdf) as pdf:
                for q in unit['questions']:
                    page=pdf[q['p']-1]; ident=q['n']
                    spans=[(ln['bbox'], ''.join(s['text'] for s in ln['spans'])) for b in page.get_text('dict')['blocks'] if 'lines' in b for ln in b['lines']]
                    def starts_with(number):
                        return [i for i,(_,s) in enumerate(spans) if re.match(rf'^\s*(?:Q\.?\s*)?{number}\s*[.)]',s,re.I)]
                    # The supplied compilation keeps original IDs in the text layer,
                    # but many other PDFs expose their visible serial instead.
                    starts=starts_with(ident) or (starts_with(q['serial']) if q['serial']!=ident else [])
                    suffix=f"q-{ident}"
                    clip=page.rect
                    if len(starts)==1:
                        start=starts[0]; end=next((i for i in range(start+1,len(spans)) if re.match(r'\s*Correct Ans:',spans[i][1],re.I)),None)
                        if end is not None:
                            require(spans[end][1].strip() == f'Correct Ans: {q["key"]}', f'PDF key mismatch {ident}')
                            region=[b for b,_ in spans[start:end+1]]
                            clip=fitz.Rect(max(0,min(b[0] for b in region)-20),max(0,spans[start][0][1]-5),min(page.rect.x1,max(b[2] for b in region)+5),min(page.rect.y1,max(b[3] for b in region)+4))
                    pix=page.get_pixmap(matrix=fitz.Matrix(1.65,1.65),clip=clip,alpha=False)
                    Image.frombytes('RGB',(pix.width,pix.height),pix.samples).save(root/f'{suffix}.jpg',quality=91,subsampling=0)
                results.append(f'{len(unit["questions"])} witnesses in {root}')
        with (root/'inventory.txt').open('w',encoding='utf-8') as out:
            if mode=='theory':
                for n,r in unit['source']['indexed']:
                    if r[0]!='@': print(f'{n:02d}: '+ ' | '.join(r),file=out)
            elif mode=='practice':
                for q in unit['questions']:print(f'{q["id"]} · ({q["key"]}) {q["valid_option"]}\n{q["question"]}\n'+ ' | '.join(f'{a} {b}' for a,b in zip(q['letters'],q['options'])),file=out)
            else:
                for q in unit['questions']:print(f'{q["n"]} · प्र. {q["serial"]} · {q["shift_title"]} · PDF {q["p"]} · कुंजी {q["key"]}\n{q["question"]}\n'+ ' | '.join(q['options']),file=out)
        dump(root/'witness.json',evidence)
        print(f'PREPARED {key} [{mode}] · '+', '.join(results)+f' · {root}/inventory.txt')

    def check(self, key, reviewed=False, *, return_only=False):
        mode, unit = self.unit(key)
        note = self.file('notes') / f'{key}.txt'
        (i, intro), *rows = lines(note)
        require(len(intro)==3 and intro[0]=='!' and meaningful(intro[2])>=10, f'{key}: title and useful intro required')
        src = unit.get('source'); valid={n for n,r in src['indexed'] if r[0]!='@'} if src else set()
        h=[]; linked=set(); flags=0; solutions={}; words=0; contrasts=0
        def refs(s):
            r=[v.strip() for v in s.split(',') if v.strip()]
            require(len(r)==len(set(r)) and all(v in self.refs for v in r),f'{key}: unknown/duplicate reference in {s}')
            return r
        for i,r in rows:
            op,*c=r; require(all(c), f'{key}:{i}: use nonempty fields')
            if mode=='theory':
                if op=='H':
                    require(len(c) in (2,3), f'{key}:{i}: expected H|title|anchors|references(optional)')
                    current=set()
                    for token in c[1].split(','):
                        m=re.fullmatch(r'(\d+)(?:-(\d+))?',token.strip());require(m is not None, f'{key}: bad anchor {token}')
                        a,b=int(m[1]),int(m[2] or m[1]);require(1<a<=b<=1000,f'{key}: bad range {token}');current.update(k for k in range(a,b+1) if k in valid)
                    require(current, f'{key}:{i}: no actual headings, data, tables or figures referenced')
                    linked.update(current);h.append(dict(title=c[0],lines=sorted(current),refs=refs(c[2]) if len(c)==3 else [],body=[]));continue
                require(h and op in 'P B D T - C K'.split(), f'{key}:{i}: bad theory row {op}')
                prev=h[-1]['body'][-1] if h[-1]['body'] else None
                require((op in ('T','-') and len(c)>=2) or (op in ('P','B') and len(c)==1) or (op in ('C','D','K') and len(c)==2),f'{key}:{i}: wrong row length at {op}')
                if op=='-': require(prev and prev[0] in ('T','-') and len(prev)==len(r),f'{key}:{i}: missing/mismatched table header')
                if op=='C': flags+=1
                h[-1]['body'].append(r);words+=sum(map(meaningful,c))
            elif op=='A':
                require(len(c) in (3,4) and c[0] not in solutions, f'{key}:{i}: bad/duplicate solution row')
                require(meaningful(c[1])>=12 and meaningful(c[2])>=7,f'{key}:{i}: explain the answer and the distraction, not just the key')
                solutions[c[0]]=dict(why=c[1],compare=c[2],refs=refs(c[3]) if len(c)==4 else []);words+=meaningful(c[1])+meaningful(c[2]);contrasts+=1
            elif op=='C':
                require(len(c) in (2,3) and c[0] in solutions and 'caution' not in solutions[c[0]] and meaningful(c[1])>=12,f'{key}:{i}: caution must follow its solution')
                solutions[c[0]]['caution']=dict(text=c[1],refs=refs(c[2]) if len(c)==3 else []);flags+=1
            else:raise ValueError(f'{key}:{i}: unexpected solution row')
        if mode=='theory':
            require(valid==linked,f'{key}: unlinked source lines: {sorted(valid-linked)}')
            require(len(h)>=3 and all(sum(sum(map(meaningful,b[1:])) for b in x['body'])>=36 for x in h),f'{key}: more explanation needed in a section')
            require(words>=self.cfg.get('min_theory_words',525),f'{key}: notes too thin ({words} Hindi-containing words)')
        else:
            ids=[q['id'] if mode=='practice' else str(q['n']) for q in unit['questions']]
            require(list(solutions)==ids, f'{key}: solution mismatches/order: missing {sorted(set(ids)-solutions.keys())}; unexpected {sorted(solutions.keys()-set(ids))}')
        coverage=f'{len(linked)}/{len(valid)} source lines' if mode=='theory' else f'{len(solutions)}/{len(unit["questions"])} keys and solutions'
        print_summary = f'{key} · {mode} · {coverage} · {words} Hindi-containing words'
        stats={'unit':key,'mode':mode,'source_lines':len(valid) if mode=='theory' else 0,'mapped_lines':len(linked), 'sections':len(h),'solutions':len(solutions),'distinctions':contrasts,'cautions':flags,'words':words}
        fp=self.fingerprint(mode,unit); fp['note_sha256']=digest(note)
        draft=dict(key=key,mode=mode,title=intro[1],intro=intro[2],sections=h,solutions=solutions,input=unit,stats=stats,fingerprints=fp)
        if reviewed:
            evidence=load(self.file('scratch')/key/'witness.json')
            require(all(evidence.get(k)==v for k,v in fp.items() if k!='note_sha256'), f'{key}: source or reference data changed; prepare again')
            draft['reviewed_at']=datetime.now(timezone.utc).isoformat(timespec='seconds')
            dump(self.file('checked')/f'{key}.json',draft)
        if return_only:return draft
        print(('REVIEWED ' if reviewed else 'PASSED ')+print_summary)

    def assemble(self):
        approved=[]
        for k in self.units:
            old=load(self.file('checked')/f'{k}.json'); now=self.check(k,return_only=True)
            require(old.get('reviewed_at') and digest_obj({a:b for a,b in old.items() if a!='reviewed_at'})==digest_obj(now), f'Stale or modified review for {k}. Review again.')
            approved.append(old)
        total=Counter()
        for u in approved:total.update({k:v for k,v in u['stats'].items() if isinstance(v,int)})
        report=dict(units=[dict(u['stats'],reviewed_at=u['reviewed_at'],fingerprints=u['fingerprints']) for u in approved],totals=dict(total),source_range=[min(self.pages),max(self.pages)])
        root=self.file('checked').parent
        dump(root/'compiled.json',dict(units=approved,references=self.refs))
        dump(root/'coverage.json',report)
        print(f'ASSEMBLED {len(approved)} reviewed units: {dict(total)}')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--manifest',required=True,type=Path)
    sub=ap.add_subparsers(dest='cmd',required=True)
    sub.add_parser('list'); sub.add_parser('assemble')
    sub.add_parser('prepare').add_argument('unit')
    co=sub.add_parser('check');co.add_argument('unit');co.add_argument('--reviewed',action='store_true')
    a=ap.parse_args();p=Project(a.manifest)
    if a.cmd=='list': print('\n'.join(p.units))
    if a.cmd=='prepare': p.prepare(a.unit)
    if a.cmd=='check':p.check(a.unit,a.reviewed)
    if a.cmd=='assemble':p.assemble()


if __name__=='__main__':
    try:main()
    except (ValueError,FileNotFoundError,KeyError) as exc:
        sys.exit(f'FAIL: {exc}')
