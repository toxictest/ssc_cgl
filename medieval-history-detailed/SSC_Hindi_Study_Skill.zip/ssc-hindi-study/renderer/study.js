(() => {
'use strict';
const $=id=>document.getElementById(id), all=(s,el=document)=>[...el.querySelectorAll(s)];
const sheets=all('[data-sheet]'),pages=new Map(sheets.map(e=>[e.id,e]));
const menus=all('[data-menu]'), nav=all('[data-tab]'), links=all('[data-page-link]'), picker=$('jump'),prev=$('prev'),next=$('next');
const groupEls=all('[data-pyq-group]'), buttons=all('[data-filter]'), find=$('find'), open=$('open-keys');
const norm=s=>s.normalize('NFC').toLowerCase().replace(/[\u200b-\u200d]/g,'').trim();
const questions=all('[data-qid]').map(el=>({el, group:el.closest('[data-pyq-group]').dataset.pyqGroup, value:norm([...el.querySelectorAll('.q-strip,h3,.bank-options')].map(n=>n.textContent).join(' ')), answer:el.querySelector('details')}));
const current=(el,b)=>b?el.setAttribute('aria-current','page'):el.removeAttribute('aria-current');
let active='all';
function openLabel(){const visible=questions.filter(x=>!x.el.hidden);open.disabled=visible.length===0;open.textContent=visible.some(x=>!x.answer.open)?'दिख रहे उत्तर खोलें':'दिख रहे उत्तर छिपाएँ';}
function filter(group){
 active=group;
 const words=norm(find.value).split(/\s+/).filter(Boolean);const counts=new Map();let total=0;
 questions.forEach(({el,value,group:key})=>{const hit=(active==='all'||key===active)&&words.every(w=>value.includes(w));el.hidden=!hit;if(hit){counts.set(key,1+(counts.get(key)||0));total++;}});
 groupEls.forEach(g=>{g.hidden=!counts.get(g.dataset.pyqGroup);});buttons.forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.filter===active)));
 $('result-count').textContent=total?`${total} प्रश्न दिख रहे हैं`:'कोई प्रश्न नहीं मिला। विषय या खोज बदलें।';openLabel();
}
function step(el,dest){el.href=dest?'#'+dest:'#';el.setAttribute('aria-disabled',String(!dest));el.tabIndex=dest?0:-1;}
function getHash(){try{return decodeURIComponent(location.hash.slice(1));}catch{return '';}}
function route(scroll){
 const id=getHash();if(id==='page-tools'||id==='reader')return;
 const target=$(id), parent=target?.closest('[data-sheet]');const leading=pages.get(id)||parent||pages.get('study-22');
 const mode=leading.dataset.mode;
 sheets.forEach(el=>el.hidden=el!==leading);menus.forEach(el=>el.hidden=el.dataset.menu!==mode);nav.forEach(el=>current(el,el.dataset.tab===mode));
 const group=target?.closest('[data-pyq-group]')?.dataset.pyqGroup;
 links.forEach(el=>current(el,el.dataset.pageLink===(group?'pyq-'+group:leading.id)));
 const siblings=sheets.filter(el=>el.dataset.mode===mode);const i=siblings.indexOf(leading);
 step(prev,siblings[i-1]?.id);step(next,siblings[i+1]?.id);picker.value=leading.id;
 if(mode==='pyq'&&group){find.value='';filter(group);}
 else if(id==='pyq'){find.value='';filter('all');}
 if(scroll){requestAnimationFrame(()=>{const at=id==='home'?$('home'):target && target!==leading?target:$('page-tools');at?.scrollIntoView({block:'start'});});}
}
picker.addEventListener('change',()=>{if(location.hash==='#'+picker.value)route(true);else location.hash=picker.value;});
buttons.forEach(b=>b.addEventListener('click',()=>filter(b.dataset.filter)));find.addEventListener('input',()=>filter(active));
open.addEventListener('click',()=>{const visible=questions.filter(x=>!x.el.hidden), flag=visible.some(x=>!x.answer.open);visible.forEach(x=>x.answer.open=flag);openLabel();});
$('pyq').addEventListener('toggle',e=>{if(e.target.classList.contains('bank-answer'))openLabel();},true);
document.addEventListener('click',ev=>{const a=ev.target.closest('a[href^="#"]');if(!a||ev.defaultPrevented||ev.ctrlKey||ev.metaKey||ev.shiftKey||ev.altKey)return;if(a.getAttribute('aria-disabled')==='true'){ev.preventDefault();return;}if(a.getAttribute('href')===location.hash){ev.preventDefault();route(true);}});
addEventListener('hashchange',()=>route(true));document.documentElement.classList.add('enhanced');filter('all');route(Boolean(getHash()));
})();
