"""Decorative cover art only. Source pictures are unaltered scan crops in art/."""

def svg(w,h,s,cls=''):
    return f'<svg xmlns="http://www.w3.org/2000/svg" class="{cls}" viewBox="0 0 {w} {h}" aria-hidden="true" focusable="false">{s}</svg>'

def brand_icon():
    return svg(40,40,'<path d="M5 36V15h5v-5h5v5h10v-5h5v5h5v21H5Z" fill="#183e43"/><path d="M15 36V27q0-6 5-9 5 3 5 9v9" fill="#edc882"/><path d="M3 36h34" stroke="#183e43" stroke-width="2"/>')

def night_hero(prefix="cover"):
    # Mughal-inspired skyline, not identified as a particular source monument.
    sky='''<defs><linearGradient id="sun" x2=".4" y2="1"><stop stop-color="#fbe6b1"/><stop offset="1" stop-color="#dca361"/></linearGradient><linearGradient id="wall"><stop stop-color="#b5654f"/><stop offset="1" stop-color="#914b42"/></linearGradient></defs>
    <circle cx="239" cy="90" r="64" fill="url(#sun)"/><g fill="none" stroke="#fff0b4"><circle cx="239" cy="90" r="74" opacity=".45"/><circle cx="239" cy="90" r="83" opacity=".25"/><circle cx="239" cy="90" r="92" opacity=".11"/></g>
    <path d="M4 200 58 162 94 180 141 151 174 170 214 145 244 177 285 148 322 169 359 139 415 183V238H4Z" fill="#6f8f78"/>
    <path d="M4 216 58 181 103 200 138 186 172 210 221 183 285 206 319 179 360 194 415 166V248H4Z" fill="#477168"/>
    <path d="M24 220v-61h12v-8h7v8h14v-8h7v8h13v-8h7v8h14v-8h7v8h15v-8h7v8h17v61" fill="url(#wall)" stroke="#713d38" stroke-width="1.4"/>
    <path d="M26 166h116m-115 40h115" stroke="#e3a271" stroke-width="2"/>
    <path d="M57 220v-25q0-15 23-28 23 13 23 28v25" fill="#6b3e36" stroke="#f0b385" stroke-width="1.4"/><path d="M65 220v-24q0-11 15-21 15 10 15 21v24" fill="#273b3b"/>
    <path d="M178 154q-8-22 15-42 19-14 21-32 3 18 22 32 23 20 15 42Z" fill="#f1dcb5" stroke="#866650" stroke-width="1.4"/><path d="M212 86v-12m-3 4h6" stroke="#875d44" stroke-width="1.4"/>
    <path d="M171 153h87v12h-87Z" fill="#cfae82" stroke="#94785a" stroke-width="1.1"/><path d="M154 163h120v58H154Z" fill="#e3c396" stroke="#84644f" stroke-width="1.4"/>
    <path d="M181 217v-24q0-16 33-28 33 12 33 28v24Z" fill="#b68a68" stroke="#f9e3b5" stroke-width="2"/><path d="M189 216v-21q0-12 25-23 25 11 25 23v21Z" fill="#50665b" stroke="#815d48" stroke-width="1.5"/>
    <path d="M155 210h119m-118-42h21m76 0h20" stroke="#f2d6aa" stroke-width="1.6"/><path d="M147 219h134l5 5H142Z" fill="#ba9c72"/>
    <g fill="#e1c79b" stroke="#8b6d50" stroke-width="1.15">'''
    for x,top,size in [(145,115,14),(284,110,15),(329,130,13),(376,119,15)]:
        sky+=f'<path d="M{x-size/2} 222l2 {-200+top}h{size-4}l2 {200-top}Z"/><path d="M{x-size*.62} {top+24}q0-8 {size*.62} -12 {size*.62} 4 {size*.62} 12Z"/><path fill="#f5d9a4" d="M{x-size*.56} {top+47}h{size*1.12}v4h{-size*1.12}Zm0 30h{size*1.12}v4h{-size*1.12}Z"/>'
    sky+='''</g><path d="M318 220v-29q0-8 20-15 20 7 20 15v29h-12v-23q0-7-8-13-8 6-8 13v23Z" fill="#c89c72" stroke="#7f654f" stroke-width="1.4"/>
    <path d="M10 223h394l-7 10H18Z" fill="#c4a67a"/><path d="M5 234h411M38 242h358" stroke="#eac488" stroke-width="1.4"/><path d="M168 232h108l23 12H144Z" fill="#e4c294" opacity=".8"/>'''
    for x,y in [(31,105),(69,65),(109,96),(153,54),(328,65),(362,39),(383,96),(112,36),(395,134)]:sky+=f'<path d="M{x-3} {y}h6m-3 -3v6" stroke="#fae2a6" stroke-width="1"/>'
    return svg(420,249,sky.replace("sun",prefix+"-sun").replace("wall",prefix+"-wall"),'hero-art')
