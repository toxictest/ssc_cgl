from html import escape as E
from functools import lru_cache
from pathlib import Path
import base64,re
from PIL import Image

P=Path(__file__).resolve().parent

@lru_cache(maxsize=None)
def image_data(key):
    assert re.fullmatch('[a-z0-9]+',key)
    f=P/'art'/f'{key}.jpg'
    data=base64.b64encode(f.read_bytes()).decode('ascii')
    with Image.open(f) as im: w,h=im.size
    return data,w,h

def image(key,alt):
    data,w,h=image_data(key)
    return f'<img class="sourcephoto" alt="{E(alt,quote=True)}" width="{w}" height="{h}" src="data:image/jpeg;base64,{data}">'

GAP=re.compile(r'(\[(?:स्कैन में ढका|ढका|वाक्य आगे नहीं छपा|अक्षर नहीं छपा|अंक नहीं छपा|मूल में: [^\]]+)\])')
def text(s):
    return GAP.sub(r'<span class="gap-mark">\1</span>',E(s))

def emphasis(s):
    s=s.strip(); left,sep,right=s.partition('^')
    return f'<strong>{text(left)}</strong><span class="sep">: </span>{text(right)}' if sep else text(left)

def bullets(data,plain=False):
    items=[]
    for t in data:
        t=t.strip()
        if t.startswith('>'):
            assert items,t
            items[-1][1].append(emphasis(t[1:]))
        else:
            items.append((emphasis(t),[]))
    parts=[]
    for parent,children in items:
        child='<ul class="vb-sub">'+''.join(f'<li>{c}</li>' for c in children)+'</ul>' if children else ''
        parts.append(f'<li>{parent}{child}</li>')
    return f'<ul class="vb-list{" no-bullets" if plain else ""}">'+''.join(parts)+'</ul>'

def title(t,tag='h3',cls='vb-cap'):
    return f'<{tag} class="{cls}">{text(t.strip())}</{tag}>' if t.strip() else ''

def card(t,lines,variant=''):
    return f'<section class="vb-card {variant}">'+title(t)+f'<div class="vb-content">{bullets(lines)}</div></section>'

FLOW_WEIGHTS={
    'मुहम्मद बिन तुग़लक़':(.81,1.05,.76,.81,1.43,1.38),
    'सैयद वंश (1414–1451 ई.)':(1.32,1.13,.8,.88),
    'तालीकोटा का युद्ध या राक्षस तंगड़ी का युद्ध':(.65,1.34,1.06,1.13,.8,.92),
    'फ़िरोज़ शाह तुग़लक़ (1351 ई.–1388 ई.)':(1.01,1.02,.91,1.09,1.18),
}

def fork(t,ns):
    # The north-Indian Bhakti figure has one branch with a single leaf and one with two.
    assert len(ns)==2 and [len(s.split('~')) for s in ns]==[2,3]
    out=[]
    for j,s in enumerate(ns):
        branch,*leaves=s.split('~')
        out.append(f'<div class="vb-fork-branch b{j+1}"><div class="vb-fork-head">{emphasis(branch)}</div><ul class="vb-fork-leaves">'+''.join(f'<li>{emphasis(x)}</li>' for x in leaves)+'</ul></div>')
    return '<figure class="vb-figure vb-fork">'+title(t,'figcaption','vb-fork-root')+'<div class="vb-fork-branches">'+''.join(out)+'</div></figure>'

def flow(t,mode,ns):
    if mode=='fork':return fork(t,ns)
    assert mode in ('line','tree','chain','pyramid','snake','first-arrow','boxes'),(t,mode)
    assert ns
    weights=FLOW_WEIGHTS.get(t,[1]*len(ns));assert len(weights)==len(ns)
    grid=' '.join(f'minmax(0,{v}fr)' for v in weights)
    out=[]
    for i,s in enumerate(ns):
        head,*body=s.split('~'); sw='' if body else ' solo'
        cls='vb-node'+sw
        out.append(f'<div class="{cls}" data-node="{i+1}"><div class="vb-node-title">{emphasis(head)}</div>'+(bullets(body,plain=mode in ('line','boxes','pyramid','snake') or len(body)==1) if body else '')+'</div>')
    return f'<figure class="vb-figure vb-{mode}" style="--num:{len(ns)};--tracks:{grid}">'+title(t,'figcaption')+f'<div class="vb-nodes">'+''.join(out)+'</div></figure>'

def table(t,hs,rows):
    count=len(hs);h=''.join(f'<th scope="col">{text(x)}</th>' for x in hs)
    marked=any(x.strip() for x in hs)
    cells=[]
    for row in rows:
        if row[0]=='=':
            assert len(row)==2;cells.append(f'<tr class="vb-span"><th colspan="{count}" scope="rowgroup">{text(row[1])}</th></tr>');continue
        assert len(row)==count+1,(t,row,count)
        ss=[]
        for x in row[1:]:
            v=x.split('~');ss.append('<td>'+ (bullets(v) if len(v)>1 else emphasis(v[0]))+'</td>')
        cells.append('<tr>'+''.join(ss)+'</tr>')
    scroll=f' tabindex="0" role="region" aria-label="{E(t,quote=True)}"' if count>=6 else ''
    return f'<section class="vb-card vb-table vb-col-{count}">{title(t)}<div class="vb-table-scroll"{scroll}><table>'+ (f'<thead><tr>{h}</tr></thead>' if marked else '')+'<tbody>'+''.join(cells)+'</tbody></table></div></section>'

def photo(key,t,ps):
    mode='vb-portrait-left' if key.endswith('24') else 'vb-portrait-right'
    return f'<figure class="vb-card vb-photo vb-portrait {mode} pic-{key}">'+title(t,'figcaption')+f'<div class="vb-photo-row">'+image(key,f'{t} — मूल स्कैन से चित्र')+bullets(ps)+'</div></figure>'

def core_text(page):
    out=[];ops=page['lines'];i=0;groups=[];mid_chapter=False
    while i<len(ops):
        line=ops[i];i+=1;op,*args=line
        if op=='@':
            if args:
                assert all(re.fullmatch(r'(?:\d+(?:\.\d+)?|\.\d+)',v) and float(v)>0 for v in args),args
                fr=' '.join(f'minmax(0,{v}fr)' for v in args)
                groups.append(len(args));out.append(f'<div class="vb-grid{" vb-lane" if len(args)==1 else ""}" style="--tracks:{fr};--cols:{len(args)}">')
            else:
                assert groups, page['n'];groups.pop();out.append('</div>')
        elif op=='T':
            t,*head=args;rows=[]
            while i<len(ops) and ops[i][0] in ('-','='):rows.append(ops[i]);i+=1
            assert rows;out.append(table(t,head,rows))
        elif op=='F':out.append(flow(args[0],args[1],args[2:]))
        elif op=='B':out.append(card(args[0],args[1:]))
        elif op=='R':
            t,*b=args
            curl='<svg class="vb-curl" viewBox="0 0 22 100" preserveAspectRatio="none" aria-hidden="true" focusable="false"><path d="M21 2 Q9 2 9 16 V34 Q9 46 1 50 Q9 54 9 66 V84 Q9 98 21 98" fill="none" stroke="currentColor" stroke-width="1.15" vector-effect="non-scaling-stroke"/></svg>'
            out.append(f'<section class="vb-card vb-brace"><h3>{text(t)}</h3>{curl}<div class="vb-content">{bullets(b)}</div></section>')
        elif op=='V':out.append(photo(args[0],args[1],args[2:]))
        elif op=='M':out.append('<figure class="vb-emblem">'+image(*args)+'</figure>')
        elif op=='H':
            if args[0].startswith('2. '):
                assert not groups and not mid_chapter
                mid_chapter=True;out.append('<section class="vb-content-page vb-chapter-shift" id="chapter-2">')
            out.append(title(args[0],'h3','vb-major'))
        elif op=='J':out.append(title(args[0],'h3','vb-minor'))
        elif op=='A':out.append(title(args[0],'h4','vb-above'))
        elif op=='P':out.append('<p class="vb-lead">'+emphasis(args[0])+'</p>')
        elif op=='O':out.append('<ol class="vb-explicit">'+''.join(f'<li>{emphasis(x)}</li>' for x in args)+'</ol>')
        else:raise ValueError((page['n'],line))
    assert not groups,(page['n'],groups)
    if mid_chapter:out.append('</section>')
    return '<div class="vb-content-page">'+''.join(out)+'</div>'


def old_q(row):
    _,idx,tag,prompt,*answers=row; ans=answers[:4];letters=answers[4] if len(answers)>4 else 'abcd'; assert len(letters)==len(ans)==4
    label=''
    if tag:
        tier,year=tag.split();assert tier in ('I','II') and year.isdigit()
        label=f'<span class="old-q-locator">SSC CGL (टियर-{tier}) {year}</span>'
    qparts=prompt.split('~')
    wide=(max(map(len,ans))>41 or sum(map(len,ans))>125)
    lines=''.join(f'<p class="old-q-statement">{text(x)}</p>' for x in qparts[1:])
    opts=''.join(f'<li><b>({ch})</b><span>{text(a)}</span></li>' for ch,a in zip(letters,ans))
    return f'<article class="question old-q{" old-wide" if wide else ""}" data-old-n="{idx}"><div class="old-q-line"><b class="old-q-number">{idx}.</b><div class="old-q-main"><p class="old-q-stem">{text(qparts[0])}</p>{lines}{label}</div></div><ol class="old-options">{opts}</ol></article>'

def old_key(a):
    _,t,*cells=a
    return '<aside class="vb-key" aria-label="उत्तरमाला"><span>'+text(t)+'</span><div>'+''.join(f'<b>{text(x)}</b>' for x in cells)+'</div></aside>'

def old_text(page):
    out=['<div class="vb-q-grid"><div class="vb-q-lane">'];lane=1;closed=False
    for row in page['lines']:
        op=row[0]
        if op=='Q':out.append(old_q(row))
        elif op=='S':out.append(title(row[1],'h3','vb-quiz-head'))
        elif op=='X':assert lane==1;lane=2;out.append('</div><div class="vb-q-lane">')
        elif op=='Y':assert lane==2 and not closed;closed=True;out.append('</div></div>')
        elif op=='K':out.append(old_key(row))
        else:raise ValueError((page['n'],row))
    assert lane==2
    if not closed:out.append('</div></div>')
    return ''.join(out)
