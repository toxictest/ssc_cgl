from pathlib import Path
from html import escape as E
import base64,collections,json,os,re
from literal import core_text,old_text
from visuals import brand_icon,night_hero

P=Path(__file__).resolve().parent
OUT=P.parent/'medieval-history-verbatim'
TMP=Path(os.environ.get('MEDIEVAL_TMP','/tmp/medieval'))
DRIVE='https://drive.google.com/file/d/1JENBgfzHjJOWzjafeXRWRMW8KmJXIvi9/view'
FIRST,LAST,QFIRST=22,33,31
CSS=lambda n:(P/n).read_text()
PARTS={
 'delhi':('01','भारत में इस्लाम का प्रवेश और दिल्ली सल्तनत','#963c46','#fae8e5'),
 'deccan':('02','विजयनगर और बहमनी राज्य','#895025','#f8efdc'),
 'faith':('03','भक्ति, सूफ़ीवाद और सिख धर्म','#286653','#e8f2e6'),
 'mughal':('04','मुग़ल और उत्तरवर्ती मुग़ल','#34637c','#e8f2fa'),
 'maratha':('05','मराठे','#69528a','#f0e9f7'),
 'practice':('अ','मूल CGL अभ्यास','#35695e','#e9f3e7'),
}
GROUP_NAMES={'delhi':'दिल्ली सल्तनत','deccan':'विजयनगर–बहमनी','faith':'भक्ति–सूफ़ी–सिख','mughal':'मुग़ल और शेरशाह','maratha':'मराठे'}
TITLE='मध्यकालीन इतिहास | SSC CGL · शाब्दिक हिंदी अनुवाद'
MONTH={'Sep':'सितंबर','Oct':'अक्टूबर'}


def fonts():
 out=[]
 for weight,name in [(400,'Regular'),(700,'Bold')]:
  b64=base64.b64encode((P/'fonts'/f'NotoSansDevanagari-{name}.ttf').read_bytes()).decode()
  out.append(f'@font-face{{font-family:"Noto Hindi";font-style:normal;font-weight:{weight};font-display:swap;src:url("data:font/ttf;base64,{b64}") format("truetype")}}')
 return '\n'.join(out)
FONTSTYLE=fonts()
COPY=(P/'fonts'/'COPYRIGHT').read_text().split('\nLicense: OFL-1.1\n PREAMBLE\n',1)[1].split('\nFiles:',1)[0]
LICENSE='<!-- Embedded fonts: Noto Sans Devanagari. Copyright 2015 Google Inc. All Rights Reserved.\nSIL OPEN FONT LICENSE Version 1.1 — 26 February 2007\nPREAMBLE\n'+COPY.replace('\n .\n','\n\n').replace('--','—')+'\n-->'


def parse_source():
 pages=[]
 for f in sorted((P/'data').glob('*.txt')):
  h,*rows=[line.split('|') for line in f.read_text().splitlines() if line.strip()]
  op,n,t,g,num=h;assert op=='#' and g in PARTS
  pages.append(dict(n=int(n),title=t,group=g,chapter=num,lines=rows))
 return pages


PAGES=parse_source();GROUPS=json.loads((P/'literal-pyq.json').read_text())
assert [x['n'] for x in PAGES]==list(range(FIRST,LAST+1))
COUNTS=collections.Counter(x[0] for p in PAGES for x in p['lines'])
PYQ_N=sum(len(x['items']) for x in GROUPS);OLD_N=COUNTS['Q'];PAGE_N=len(PAGES)
assert [len(x['items']) for x in GROUPS]==[18,5,3,15,1]
assert (PAGE_N,OLD_N,PYQ_N,COUNTS['K'],COUNTS['V']+COUNTS['M'])==(12,48,42,5,9)


def style(g):
 a,b=PARTS[g][-2:];return f'--accent:{a};--pale:{b}'


def sheethead(t,sub,badge='',part='',num=''):
 return '<header class="sheethead">'+(f'<span aria-hidden="true" class="number">{E(num)}</span>' if num else '')+f'<div class="head-copy">'+(f'<div class="part">{E(part)}</div>' if part else '')+f'<h2>{E(t)}</h2>'+ (f'<p>{E(sub)}</p>' if sub else '')+'</div>'+(f'<span class="sheetbadge">{badge}</span>' if badge else '')+'</header>'


def sheet(p,print_mode):
 n=p['n']; g=p['group']; number,part,*_=PARTS[g];practice=g=='practice'
 badge=f'मूल पृष्ठ <b class="sheet-badge-num">{n}</b>'
 trail=f'स्कैन का PDF पृष्ठ {n+4}'
 if n==LAST:trail+=' · इस खंड का अंतिम पृष्ठ'
 next_id=f'p-{n+1}' if n<LAST else 'pyq'; next_label='अगला पृष्ठ →' if n<LAST else '2026 PYQ →'
 prev=f'<a href="#p-{n-1}">← पिछला</a>' if n>FIRST else ''
 addon=f'<div class="foot-actions">{prev}<a href="#{next_id}">{next_label}</a></div>'
 context='मूल CGL अभ्यास' if practice else f'अध्याय {int(number)}' + ('–2' if n==24 else '')+' · मूल पाठ'
 sub='मूल प्रश्न, विकल्प और उत्तरमाला' if practice else 'मूल पाठ का पंक्ति-दर-पंक्ति हिंदी अनुवाद'
 head=sheethead(p['title'],sub,badge,context,number)
 return f'<section class="sheet core source-sheet {"old-sheet" if practice else "theory-sheet"}" data-sheet data-original="{n}" id="p-{n}" style="{style(g)}">{head}<div class="papercontent">{old_text(p) if practice else core_text(p)}</div><footer class="pgend"><span class="pagenote">{trail}</span>{addon if not print_mode else ""}</footer></section>'


def span_text(s):
 parts=re.split(r'\s+(?=(?:[1-4]\. (?!\d)|उपरोक्त में दिए गए|उपरोक्त में से))',s)
 return E(s) if len(parts)==1 else E(parts[0])+'<span class="qlines">'+''.join(f'<span>{E(x)}</span>' for x in parts[1:])+'</span>'


def get_pyq(r,print_mode):
 m=re.fullmatch(r'\d+\. (\d+) (Sep|Oct) (\d{4}) - Shift (\d+)',r['shift_title']);assert m,r['shift_title']
 day,mon,y,shift=m.groups();stamp=f'{int(day)} {MONTH[mon]} {y} · शिफ़्ट {shift} · PDF पृ. {r["p"]}'
 q=r['question']; opts=r['options']; key=r['key']; why=r.get('why',''); n=r['n']; pos=r['serial']
 assert len(opts)==4 and key in 'ABCD' and 1<=pos<=1325
 o=''.join(f'<li><b>{i}.</b><span>{E(x)}</span></li>' for i,x in zip('ABCD',opts))
 cls='question'+(' long' if max(map(len,opts))>52 or sum(map(len,opts))>150 else '')
 note=f'<p class="why"><strong>टिप्पणी:</strong> {E(why)}</p>' if why else ''
 answer=(f'<div class="qans"><b>संकलन का उत्तर:</b> {key}{note}</div>' if print_mode
   else f'<details class="qans"><summary>संकलन का उत्तर देखें</summary><p><b>{key}</b> · {E(opts["ABCD".index(key)])}</p>{note}</details>')
 return f'<article class="{cls}" id="q-{n}" data-qid="{n}" data-serial="{pos}"><div class="qmeta"><b><span class="prser">प्र.</span> {pos} <span class="ref-dot">·</span> <span class="qid-small">ID {n}</span></b><span class="qpill">{stamp}</span></div><p class="qtext">{span_text(q)}</p><ol class="qopts">{o}</ol>{answer}</article>'


def pyq_method(compact=False):
 link=f'<a class="source-link" href="{DRIVE}" target="_blank" rel="noopener noreferrer">'
 if compact:return f'<div class="method compact-method"><b>कुंजी:</b> {link}2026 संकलन</a> के उत्तर; आधिकारिक अंतिम कुंजी नहीं।</div>'
 return f'<div class="method"><b>स्रोत:</b> आपकी साझा {link}SSC CGL 2026 टियर-I PDF</a>। ‘प्र.’ PDF में दिखने वाली प्रश्न-संख्या है; ‘ID’ उसकी टेक्स्ट लेयर का संदर्भ है। साथ में तारीख, शिफ़्ट और PDF पृष्ठ हैं। <b>उत्तर संकलन की कुंजी से हैं, आधिकारिक अंतिम कुंजी से नहीं।</b></div>'


def pyq_screen():
 head=sheethead('SSC CGL 2026 · विषयवार PYQ','टियर-I · हिंदी प्रश्न और पूरे विकल्प',f'{PYQ_N} प्रश्न','परिशिष्ट','26')
 buttons='<button type="button" class="btn pale" data-picker="all" aria-pressed="true">सभी</button>'+''.join(f'<button type="button" class="btn pale" data-picker="{x["id"]}" aria-pressed="false">{E(GROUP_NAMES[x["id"]])} · {len(x["items"])}</button>' for x in GROUPS)
 ctrl='<div class="pyq-controls"><label class="pyq-search"><span>खोजें</span><input id="pyq-search" type="search" placeholder="शब्द, प्रश्न-संख्या या ID" autocomplete="off"></label><button class="btn pale" type="button" id="toggle-answers">उत्तर खोलें</button></div>'
 groups=[]
 for x in GROUPS:
  k=x['id']; title=x['title'];n=len(x['items'])
  groups.append(f'<section class="append-group" id="pyq-{k}" data-pyq-group="{k}" data-count="{n}" style="{style(k)}"><h3>{E(title)} <small><a class="group-link" href="#{x["anchor"]}">मूल पाठ पृ. {x["notes"]}</a></small></h3><div class="practice">'+''.join(get_pyq(r,False) for r in x['items'])+'</div></section>')
 return f'<section class="sheet append-screen" id="pyq" data-sheet style="{style("practice")}">{head}'+pyq_method()+f'<div class="screen-only">{ctrl}<div class="pyq-buttons" aria-label="PYQ विषय">{buttons}</div><p class="pyq-info" id="pyq-count" aria-live="polite">{PYQ_N} प्रश्न दिख रहे हैं</p></div>'+''.join(groups)+'</section>'


def pyq_seed():
 out=[]
 for count,x in enumerate(GROUPS,1):
  k=x['id'];title=x['title'];subtitle='SSC CGL 2026 · टियर-I · मूल पाठ पृ. '+x['notes']
  h=sheethead(title,subtitle,f'{len(x["items"])} प्रश्न',f'2026 PYQ · विषय {count:02d} / {len(GROUPS):02d}','26')
  single=' append-single' if len(x['items'])==1 else ''
  out.append(f'<section class="sheet appendix" data-seed="{k}" style="{style(k)}"><section class="append-segment{single}" id="pyq-{k}" style="{style(k)}">'+h+pyq_method(count!=1)+'<div class="practice-columns"><div class="practice-col">'+''.join(get_pyq(r,True) for r in x['items'])+'</div><div class="practice-col"></div></div><footer class="pgend"></footer></section></section>')
 return ''.join(out)


def links_by_part(g):
 pages=[(f'p-{p["n"]}',p['title'],p['n']) for p in PAGES if p['group']==g]
 if g=='deccan':pages.insert(0,('chapter-2','विजयनगर · अध्याय 2 की शुरुआत',24))
 if g=='practice':pages=[(id,f'CGL अभ्यास · मूल पृ. {n}',n) for id,t,n in pages]
 return pages


def cover():
 stats=f'<div class="cover-stats"><span><b>{PAGE_N}</b> मूल पन्ने · 22–33</span><span><b>{OLD_N}</b> मूल अभ्यास प्रश्न</span><span><b>{PYQ_N}</b> PYQ · वर्ष 2026</span></div>'
 lanes=['','']
 for j,(g,(i,name,*_)) in enumerate(PARTS.items()):
  links=''.join(f'<a href="#{id}"><span>{E(t)}</span><i>{n}</i></a>' for id,t,n in links_by_part(g))
  lanes[int(j>2)]+=f'<section class="toc-section" style="{style(g)}"><h3>{E(i)} · {E(name)}</h3>{links}</section>'
 groups=''.join(f'<a href="#pyq-{x["id"]}">{E(GROUP_NAMES[x["id"]])}<b>{len(x["items"])} प्रश्न</b></a>' for x in GROUPS)
 return f'''<section class="toc-cover print-only" id="top"><header class="cover-cover"><div><div class="cover-tag">SSC CGL • GENERAL AWARENESS</div><h1>मध्यकालीन इतिहास</h1><p>मूल पाठ का पंक्ति-दर-पंक्ति हिंदी अनुवाद<br>मूल चित्र, आरेख, तालिकाएँ और CGL अभ्यास</p><span class="cover-writer">Writer: Sonu Shakya</span></div>{night_hero('pdf')}</header>{stats}<h2 class="toc-title">मूल पृष्ठों की विषय-सूची</h2><div class="toc-cols"><div>{lanes[0]}</div><div>{lanes[1]}</div></div><h2 class="toc-title">परिशिष्ट · 2026 के PYQ</h2><div class="toc-group-grid">{groups}</div><div class="method"><b>पढ़ने का तरीका:</b> ‘मूल पृष्ठ’ किताब में छपी संख्या है; स्कैन के PDF में यह संख्या 4 अधिक है। मूल पाठ के कथन, तिथियाँ, प्रश्न, विकल्प-क्रम और उत्तरमालाएँ स्रोत के अनुसार रखी गई हैं। 2026 वाले प्रश्न अलग परिशिष्ट में हैं।</div><footer class="cover-meta"><span>केवल मध्यकालीन इतिहास · अगले खंड से पहले तक</span><span>बिना किसी बाहरी फ़ाइल के पढ़ें</span></footer></section>'''


def basic_head(style_add):
 return f'<!doctype html><html lang="hi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="author" content="Sonu Shakya"><meta name="description" content="SSC CGL मध्यकालीन इतिहास — मूल पृष्ठ 22–33 का शाब्दिक हिंदी अनुवाद, चित्र, आरेख, तालिकाएँ, अभ्यास और 2026 के विषयवार PYQ।"><meta name="theme-color" content="#174852"><title>{TITLE}</title><style>{FONTSTYLE}</style>{style_add}</head>'


def site():
 nav=''
 for g,(_,name,*_) in PARTS.items():
  nav+=f'<h3>{E(name)}</h3><ol>'+''.join(f'<li><a href="#{id}" data-page-link="{id}"><span>{n}</span>{E(t)}</a></li>' for id,t,n in links_by_part(g))+'</ol>'
 options=''.join(f'<option value="p-{p["n"]}">{p["n"]} · {E(p["title"])}</option>' for p in PAGES)
 all_pages=''.join(sheet(x,False) for x in PAGES)
 top=f'''<a class="skip" href="#page-tools">सीधे पाठ पर जाएँ</a><header class="mast screen-only" id="view-top"><div class="wrap mast-inner"><a class="brand" href="#p-{FIRST}"><span class="mark">{brand_icon()}</span><span>मध्यकालीन इतिहास<em>SSC CGL · हिंदी</em></span></a><nav aria-label="मुख्य नेविगेशन"><a href="#p-{FIRST}" id="nav-reading">मूल पन्ने</a><a href="#p-{QFIRST}" id="nav-practice">अभ्यास</a><a href="#pyq" id="nav-pyq">2026 PYQ</a></nav><span class="byline">Writer: Sonu Shakya</span></div></header><section class="wrap hero screen-only"><div><span class="eyebrow">SSC CGL · GENERAL AWARENESS</span><h1>मध्यकालीन इतिहास</h1><p>मूल पृ. 22–33 का पंक्ति-दर-पंक्ति हिंदी अनुवाद। मूल चित्र, आरेख, तालिकाएँ और CGL अभ्यास उसी क्रम में हैं। 2026 के प्रश्न अलग विषयवार परिशिष्ट में हैं।</p><div class="hero-links"><a href="#p-{FIRST}" class="btn gold">पढ़ना शुरू करें →</a><a href="#pyq" class="btn ghost">2026 PYQ</a><span class="substat"><b>{PAGE_N}</b> मूल पन्ने</span><span class="substat"><b>{OLD_N}</b> मूल अभ्यास प्रश्न</span><span class="substat"><b>{PYQ_N}</b> 2026 के PYQ</span></div></div>{night_hero('web')}</section>'''
 aside=f'<aside class="side screen-only" aria-label="पृष्ठ सूची"><h2>मूल पृष्ठों का क्रम</h2>{nav}<h3>परिशिष्ट</h3><a href="#pyq" data-page-link="pyq"><span>26</span>2026 के विषयवार PYQ</a></aside>'
 tools=f'<div class="toolbar screen-only" id="page-tools"><div class="jump"><label for="jump">पृष्ठ चुनें</label><select id="jump">{options}<option value="pyq">परिशिष्ट · 2026 PYQ</option></select></div><div class="nextprev"><a href="#p-{FIRST}" class="btn pale" id="prev" aria-label="पिछला मूल पृष्ठ">← पिछला</a><a href="#p-{FIRST+1}" class="btn pale" id="next" aria-label="अगला मूल पृष्ठ">अगला →</a></div></div>'
 end='<footer class="footer screen-only"><div class="wrap"><span>SSC CGL · मध्यकालीन इतिहास</span><span>मूल अभ्यास और 2026 के प्रश्न अलग रखे गए हैं।</span></div></footer>'
 styles='<style media="screen">'+CSS('typography.css')+CSS('screen.css')+CSS('medieval.css')+'</style><style media="print">'+CSS('typography.css')+CSS('print.css')+CSS('medieval.css')+'\n[data-pyq-group][hidden],.question[hidden]{display:block!important}.append-screen .qans>*{display:block!important}.append-screen .qans::details-content{content-visibility:visible!important}</style>'
 # The A4 source scaling is computed once during delivery; reuse it for native browser printing.
 scale=TMP/'printsizes.json'
 sizing=''
 if scale.is_file():
  sizing='<style media="print">'+''.join(f'[data-original="{n}"]{{--zoom:{z}}}' for n,_,z,_ in json.loads(scale.read_text()))+'</style>'
 return basic_head(styles+sizing)+f'<body>{LICENSE}{cover()}{top}<div class="wrap layout">{aside}<main id="book">{tools}<noscript><p class="noscript">स्क्रिप्ट बंद है, इसलिए सभी मूल पृष्ठ और प्रश्न नीचे क्रम से दिख रहे हैं।</p></noscript>{all_pages}{pyq_screen()}</main></div>{end}<script>{CSS("app.js")}</script></body></html>'


def build():
 OUT.mkdir(parents=True,exist_ok=True);TMP.mkdir(parents=True,exist_ok=True)
 (OUT/'index.html').write_text(site())
 h=basic_head('<style>'+CSS('typography.css')+CSS('print.css')+CSS('medieval.css')+'</style>')
 (TMP/'print.html').write_text(h+'<body>'+cover()+'<main id="print-pages">'+''.join(sheet(x,True) for x in PAGES)+pyq_seed()+'</main></body></html>')
 print(f'Core: {PAGE_N} source sheets; {OLD_N} practice; {dict(COUNTS)}')
 print('Appendix:',PYQ_N,[len(x['items']) for x in GROUPS]);print('HTML:',(OUT/'index.html').stat().st_size,'bytes')

if __name__=='__main__':build()
