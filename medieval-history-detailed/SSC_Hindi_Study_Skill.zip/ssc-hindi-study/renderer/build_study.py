from pathlib import Path
from html import escape as e
import json, re, sys, os

HERE=Path(__file__).resolve().parent
BASE=Path(os.environ.get('STUDY_CORE',HERE.parent/'.medieval-history-work')).resolve()
CASE=Path(os.environ.get('STUDY_CASE',HERE.parent/'skills/ssc-hindi-study/.case-medieval')).resolve()
OUT=Path(os.environ.get('STUDY_OUT',HERE.parent/'medieval-history-detailed')).resolve()
TMP=Path(os.environ.get('STUDY_TMP','/tmp/medieval-study'))
sys.path.insert(0,str(BASE))
import build as base
from visuals import brand_icon,night_hero

J=json.loads((CASE/'compiled.json').read_text(encoding='utf-8'))
units=J['units']; theory=[u for u in units if u['mode']=='theory']; practice=[u for u in units if u['mode']=='practice']; bank=[u for u in units if u['mode']=='bank']
references=J['references']; bynum={u['input']['source']['n']:u for u in theory+practice}
used=set()
for u in units:
 for s in u['sections']:used.update(s['refs'])
 for s in u['solutions'].values():used.update(s['refs']);used.update(s.get('caution',{}).get('refs',[]))
refs={k:v for k,v in references.items() if k in used}; refnums={k:i for i,k in enumerate(refs,1)}
labels={'delhi':'दिल्ली सल्तनत','deccan':'विजयनगर–बहमनी','faith':'भक्ति, सूफ़ी और सिख धर्म','mughal':'मुग़ल और सूरी','maratha':'मराठे'}
short={22:'सिंध से दिल्ली तक',23:'रज़िया से सैयद वंश',24:'लोदी और विजयनगर का उदय',25:'विजयनगर, बहमनी और दक्कन',26:'भक्ति की धाराएँ और कवि',27:'सूफ़ी परंपराएँ और सिख गुरु',28:'बाबर, हुमायूँ और अकबर',29:'सूरी से उत्तरवर्ती मुग़ल तक',30:'शिवाजी, पेशवा और कंपनी'}
P2G={22:'delhi',23:'delhi',24:'delhi',25:'deccan',26:'faith',27:'faith',28:'mughal',29:'mughal',30:'maratha'}
START={'delhi':22,'deccan':25,'faith':26,'mughal':28,'maratha':30}
MODES={'study':'विस्तृत पाठ','source':'मूल पृष्ठ','sol':'अभ्यास के हल','pyq':'2026 PYQ','refs':'संदर्भ'}
QS=sum(len(u['input']['questions']) for u in practice); BQS=sum(len(u['input']['questions']) for u in bank)
assert (len(theory),len(practice),QS,BQS)==(9,3,48,42)
css=lambda root,n:(root/n).read_text(encoding='utf-8')
zoom='<style media="print">'+''.join(f'[data-original="{n}"]{{--zoom:{z}}}' for n,_,z,_ in json.loads((BASE/'proof/printsizes.json').read_text(encoding='utf-8')))+'</style>'
TITLE='मध्यकालीन इतिहास — विस्तृत हिंदी अध्ययन संस्करण | SSC CGL'


def a(h,t,cls='',**attrs):
 other=''.join(f' {k.replace("_","-")}="{e(str(v))}"' for k,v in attrs.items())
 return f'<a href="#{h}"'+(f' class="{cls}"' if cls else '')+other+f'>{e(t)}</a>'


def linkrefs(keys):
 if not keys:return ''
 return '<span class="cite-links" aria-label="संदर्भ">'+''.join(a('ref-'+k,f'[{refnums[k]}]',title=refs[k]['title']) for k in keys)+'</span>'


def header(title,desc,eyebrow,badge='',kind=''):
 return f'<header class="reader-head {kind}" data-unit-head><div class="kicker">{e(eyebrow)}</div><div class="headrow"><h2>{e(title)}</h2>'+ (f'<span class="folio-badge">{e(badge)}</span>' if badge else '')+f'</div><p class="intro">{e(desc)}</p></header>'


def blocks(rows):
 i=0; res=[]
 while i<len(rows):
  op,*data=rows[i];i+=1
  if op=='P':res.append(f'<p class="note-prose">{e(data[0])}</p>')
  elif op=='B':res.append(f'<p class="note-bullet">{e(data[0])}</p>')
  elif op in 'D C K'.split():
   kind={'D':'term','C':'caution','K':'tip'}[op]
   label={'D':'शब्दार्थ','C':'स्रोत-नोट','K':'परीक्षा संकेत'}[op]
   res.append(f'<aside class="callout {kind}"><div><span class="call-tag">{label}</span> <strong>{e(data[0])}</strong></div><p>{e(data[1])}</p></aside>')
  elif op=='T':
   cols=len(data);h='<thead><tr>'+''.join('<th scope="col">'+e(t)+'</th>' for t in data)+'</tr></thead>';b=[]
   while i<len(rows) and rows[i][0]=='-':
    _,r,*rest=rows[i];i+=1;b.append('<tr><th scope="row">'+e(r)+'</th>'+''.join('<td>'+e(t)+'</td>' for t in rest)+'</tr>')
   res.append(f'<div class="dtable cols-{cols}"><table>'+h+'<tbody>'+''.join(b)+'</tbody></table></div>')
  else:raise ValueError(op)
 return ''.join(res)


def study(u,print_mode=False):
 n=u['input']['source']['n']; g=P2G[n]; label=f'विस्तृत पाठ · {n-21:02d} / 09'; sections=u['sections']
 head=header(u['title'],u['intro'],label,f'मूल पृ. {n}')
 tools='<div class="cross-links">'+a(f'p-{n}',f'मूल पृष्ठ {n} देखें ↗','btn pale')+a('pyq-'+g,'इस विषय के 2026 प्रश्न →','btn pale')+(a('pyq-deccan','विजयनगर के 2026 प्रश्न →','btn pale') if n==24 else '')+'</div>'
 nav='<nav class="inpage screen-only" aria-label="इस पृष्ठ में"><strong>इस अध्ययन-पृष्ठ में</strong><ol>'+''.join(f'<li>{a(f"s-{n}-{i}",s["title"])}</li>' for i,s in enumerate(sections,1))+'</ol></nav>'
 body=''.join(f'<section id="s-{n}-{i}" class="note-block" data-atom data-anchor-lines="{",".join(map(str,s["lines"]))}"><div class="sub-head"><span class="sub-no">{i:02d}</span><h3>{e(s["title"])}</h3>{linkrefs(s["refs"])}</div>{blocks(s["body"])}</section>' for i,s in enumerate(sections,1))
 return f'<section class="readerSheet study-sheet" data-sheet data-mode="study" data-partition="study" id="study-{n}" style="{base.style(g)}">{head}{"" if print_mode else tools+nav}<div class="unit-body" data-unit-body>{body}</div><footer class="reader-foot">{a(f"p-{n}", f"मूल पाठ · पृ. {n}")}{a("refs","संदर्भ सूची")}</footer></section>'


def old_id(q):return 'old-'+str(q['page'])+'-'+q['id'].replace('/','-')

def sol_id(q):return 'ans-'+str(q['page'])+'-'+q['id'].replace('/','-')

def original(u,print_mode=False):
 src=u['input']['source']; n=src['n']; out=base.sheet(src,True)
 # Add article destinations, not new text or metadata in the original layer.
 qs=iter(u['input']['questions'])
 def mark(m):
  q=next(qs);assert int(m[1])==q['number'];return f'data-old-n="{m[1]}" id="{old_id(q)}"'
 out=re.sub(r'data-old-n="(\d+)"',mark,out)
 out=out.replace('data-sheet data-original', 'data-sheet data-mode="source" data-original',1)
 if not print_mode:
  nav=a(f'study-{n}' if n<31 else f'sol-{n}', 'इस पृष्ठ का विस्तृत अध्ययन →' if n<31 else 'सभी उत्तर कारण सहित →','btn pale')
  out=out.replace('<div class="papercontent">',f'<div class="cross-links screen-only">{nav}{a("study-22","विस्तृत पाठ की विषय-सूची","btn pale")}</div><div class="papercontent">',1)
 return out


def qex(s):
 body=f'<p class="reason"><strong>क्यों:</strong> {e(s["why"])} {linkrefs(s["refs"])}</p><p class="compare"><strong>विकल्पों में फर्क:</strong> {e(s["compare"])}</p>'
 if s.get('caution'):
  c=s['caution'];body+=f'<aside class="answer-caution"><strong>स्रोत-नोट:</strong> {e(c["text"])} {linkrefs(c["refs"])}</aside>'
 return body


def solution(u,print_mode=False):
 n=u['input']['source']['n'];qs=u['input']['questions']; title=f'हल · मूल पृष्ठ {n}'
 head=header(title,u['intro'],'मूल CGL अभ्यास · व्याख्या',f'{len(qs)} प्रश्न'); toolbar='<div class="cross-links">'+a(f'p-{n}','मूल प्रश्न और विकल्प ↗','btn pale')+'</div>'
 cards=[]
 for q in qs:
  s=u['solutions'][q['id']]
  meta=f'<div class="q-strip"><span>{e(labels[q["topic"]])} · प्रश्न {q["number"]}</span>{a(old_id(q),"मूल विकल्प ↗")}</div>'
  cards.append(f'<article class="answer-card" id="{sol_id(q)}" data-atom data-solution="{q["id"]}">{meta}<h3>{e(q["question"])}</h3><div class="worked"><p class="key-label"><b>पुस्तक की कुंजी</b> ({q["key"]}) · {e(q["valid_option"])}</p>{qex(s)}</div></article>')
 return f'<section class="readerSheet solution-sheet" data-mode="sol" data-sheet data-partition="solution" id="sol-{n}" style="{base.style("practice")}">{head}{"" if print_mode else toolbar}<div class="unit-body" data-unit-body>{"".join(cards)}</div><footer class="reader-foot">{a(f"p-{n}",f"मूल प्रश्न · पृ. {n}")}</footer></section>'


def bank_item(r, s, print_mode=False):
 n=r['n'];m=re.fullmatch(r'\d+\. (\d+) (Sep|Oct) (\d{4}) - Shift (\d+)',r['shift_title']); assert m
 d,mon,yr,shift=m.groups(); k=r['key'];right=r['options']['ABCD'.index(k)]
 opts=''.join(f'<li><b>{ch}.</b><span>{e(o)}</span></li>' for ch,o in zip('ABCD',r['options']))
 why=f'<div class="worked"><p class="key-label"><b>संकलन की कुंजी</b> {k} · {e(right)}</p>{qex(s)}</div>'
 answer=why if print_mode else f'<details class="bank-answer"><summary>उत्तर और व्याख्या देखें</summary>{why}</details>'
 stamp=f'{int(d)} {base.MONTH[mon]} {yr} · शिफ़्ट {shift} · PDF पृ. {r["p"]}'
 return f'<article class="bank-card" id="q-{n}" data-atom data-qid="{n}" data-serial="{r["serial"]}" data-key="{k}"><div class="q-strip"><span>प्र. {r["serial"]} · ID {n}</span><span>{stamp}</span></div><h3>{base.span_text(r["question"])}</h3><ol class="bank-options" aria-label="चार विकल्प">{opts}</ol>{answer}</article>'


def bank_group(u,print_mode):
 g=u['input']['group']; key=g['id']; q=g['items']; n=START[key]; id=f'pyq-{key}'
 badge=f'{len(q)} प्रश्न'; title=labels[key]; stamp='वर्ष 2026 · विषयवार PYQ'
 if print_mode:
  head=header(title,u['intro'],stamp,badge)
 else:
  head=f'<header class="bank-title"><h3>{e(title)} <small>· {badge}</small></h3>{a(f"study-{n}","विस्तृत पाठ ↗")}</header>'
 body=''.join(bank_item(r,u['solutions'][str(r['n'])],print_mode) for r in q)
 return f'<section id="{id}" class="bank-group'+(' readerSheet bank-print' if print_mode else '')+f'" style="{base.style(key)}" data-pyq-group="{key}"'+(' data-partition="bank"' if print_mode else '')+f'>{head}<div class="unit-body" data-unit-body>{body}</div>'+ (f'<footer class="reader-foot">{a(f"study-{n}", "विस्तृत पाठ · "+str(n))}<span>उत्तर संकलन की कुंजी से हैं।</span></footer>' if print_mode else '')+'</section>'


def bank_screen():
 h=header('SSC CGL 2026 के PYQ','तारीख़, शिफ़्ट, PDF पृष्ठ और मूल क्रमांक के साथ पूरे प्रश्न। उत्तर खोलने पर कारण और विकल्पों का फर्क दिखाई देगा।','टियर-I · विषयवार प्रश्न',f'{BQS} PYQ')
 btns='<button type="button" data-filter="all" aria-pressed="true">सभी · 42</button>'+''.join(f'<button type="button" data-filter="{u["key"][5:]}" aria-pressed="false">{e(labels[u["key"][5:]])} · {len(u["input"]["questions"])}</button>' for u in bank)
 inputs=f'<div class="filtertools screen-only needs-js"><div class="filters" aria-label="विषय चुनें">{btns}</div><div class="find-line"><label for="find">प्रश्न खोजें<input id="find" type="search" placeholder="शब्द, प्रश्न संख्या या ID" autocomplete="off"></label><button type="button" id="open-keys" class="btn pale">दिख रहे उत्तर खोलें</button></div><p id="result-count" aria-live="polite">42 प्रश्न</p></div>'
 method=f'<p class="key-disclaimer">‘प्र.’ संकलन में छपी संख्या है। ‘ID’ उसकी टेक्स्ट लेयर का संदर्भ है। कुंजी <a href="{base.DRIVE}" target="_blank" rel="noopener noreferrer">साझा PDF संकलन</a> से है, आधिकारिक अंतिम उत्तर-कुंजी नहीं।</p>'
 return f'<section class="readerSheet pyq-sheet" id="pyq" data-mode="pyq" data-sheet style="{base.style("practice")}">{h}{method}{inputs}'+''.join(bank_group(u,False) for u in bank)+'</section>'


def bibliography():
 h=header('स्रोत और पाठ पढ़ने का तरीका','मूल किताब, प्रश्न-संकलन और व्याख्यात्मक संदर्भ तीन अलग चीज़ें हैं। नीचे हर संदर्भ का क्रमांक पाठ में क्लिक करके खोल सकते हैं।','संदर्भ सूची')
 source=f'''<div class="source-legend"><p><b>मूल किताब:</b> SSC CGL General Awareness, मुद्रित पृ. 22–33 (स्कैन PDF में 26–37)। मूल चित्र, आरेख, तालिकाएँ, विकल्प-क्रम और उत्तरमाला अनुवाद में रखे हैं।</p><p><b>2026 के प्रश्न:</b> <a href="{base.DRIVE}" target="_blank" rel="noopener noreferrer">साझा SSC CGL 2026 टियर-I संकलन</a>; प्रश्न के साथ तारीख़, शिफ़्ट, मुद्रित क्रमांक, ID और PDF की वास्तविक पृष्ठ संख्या दी है।</p><p><b>अध्ययन और समाधान:</b> विस्तार में अर्थ, उदाहरण और तुलनाएँ नए हैं। ‘स्रोत-नोट’ में असंदिग्ध और विवादित दावों का फर्क बताया गया है; इससे मूल अनुवाद या कुंजी नहीं बदली।</p></div>'''
 links=''.join(f'<li id="ref-{k}"><span>[{i}]</span><a href="{e(refs[k]["url"])}" target="_blank" rel="noopener noreferrer">{e(refs[k]["title"])}</a></li>' for k,i in refnums.items())
 return f'<section id="refs" class="readerSheet ref-sheet" data-mode="refs" data-sheet>{h}{source}<ol class="reference-list">{links}</ol></section>'


def tabnav():
 ids={'study':'study-22','source':'p-22','sol':'sol-31','pyq':'pyq','refs':'refs'}
 return ''.join(a(ids[k],t,data_tab=k) for k,t in MODES.items())


def landing():
 return f'''<section class="feature wrap screen-only" id="home"><div class="feature-copy"><span class="eyebrow">SSC CGL &nbsp; / &nbsp; GENERAL AWARENESS</span><h1>मध्यकालीन इतिहास</h1><p class="edition-name">विस्तृत हिंदी अध्ययन संस्करण</p><p>घटनाओं का क्रम और कारण समझें। फिर मूल पृष्ठ देखें और उत्तर का तर्क जानें—व्याख्या, मूल अनुवाद और PYQ अलग-अलग हैं।</p><div class="hero-links">{a('study-22','विस्तार से पढ़ें →','btn gold')}{a('p-22','मूल पाठ देखें','btn ghost')}</div></div>{night_hero('detail-web')}<div class="feature-stats"><span><b>09</b> विस्तृत अध्ययन-पृष्ठ</span><span><b>12</b> मूल पृष्ठ पूरे</span><span><b>90</b> प्रश्न कारण सहित</span></div></section>'''


def cover():
 def toc(items):return '<ul>'+''.join(f'<li>{a(h,t)}'+(f'<small>{n}</small>' if n else '')+'</li>' for h,t,n in items)+'</ul>'
 lead=f'''<section class="cover print-only" id="toc"><div class="cover-banner"><div><p>SSC CGL / GENERAL AWARENESS</p><h1>मध्यकालीन इतिहास</h1><h2>विस्तृत हिंदी अध्ययन संस्करण</h2><span>Writer: Sonu Shakya</span></div>{night_hero('detail-print')}</div><div class="cover-counts"><div><b>09</b> विस्तृत अध्ययन इकाइयाँ</div><div><b>12</b> मूल पृष्ठ · 22–33</div><div><b>90</b> प्रश्नों के हल</div></div><p class="cover-caption">विस्तृत पाठ में कारण, उदाहरण और तुलना। मूल पाठ में वही सामग्री और उत्तरमाला। स्रोत-नोट में दोनों को अलग करके पढ़ें।</p>'''
 notes=toc([(f'study-{n}',short[n],f'मूल {n}') for n in range(22,31)])
 originals='<div class="original-links">'+''.join(a(f'p-{n}',str(n)) for n in range(22,34))+'</div>'
 answers=toc([(f'sol-{n}',f'मूल अभ्यास पृष्ठ {n} · हल',f'{len(bynum[n]["input"]["questions"])} प्रश्न') for n in range(31,34)])
 qs=toc([(f'pyq-{g["key"][5:]}',labels[g['key'][5:]],f'{len(g["input"]["questions"])} प्रश्न') for g in bank])
 return lead+f'<div class="cover-toc"><div><h3>01 · विस्तृत अध्ययन</h3>{notes}<h3>02 · मूल अनुवाद एवं अभ्यास</h3><p>पुस्तक में मुद्रित पृष्ठ-संख्या:</p>{originals}</div><div><h3>03 · मूल अभ्यास के हल</h3>{answers}<h3>04 · 2026 PYQ · व्याख्या सहित</h3>{qs}<h3>{a("refs","05 · संदर्भ सूची ↗")}</h3></div></div><div class="cover-note"><b>नोट:</b> 2026 संकलन की कुंजी और ऐतिहासिक स्पष्टीकरण अलग दिए हैं। मूल पृ. 34 से आधुनिक इतिहास शुरू होता है; वह यहाँ शामिल नहीं है।</div></section>'


def sidebar():
 out='<aside id="side-menu" class="side screen-only" aria-label="खंड सूची"><h2>विषय-सूची</h2><div class="side-set" data-menu="study">'
 for j,(k,t) in enumerate(labels.items(),1):
  out+=f'<h3>{j:02d} · {e(t)}</h3><ol>'
  out+=''.join(f'<li>{a(f"study-{n}",short[n],data_page_link=f"study-{n}")}</li>' for n in short if P2G[n]==k)
  out+='</ol>'
 out+='</div><div class="side-set" data-menu="source"><h3>किताब में छपे पृष्ठ</h3>'
 for n in range(22,34):out+=a(f'p-{n}',f'{n} · {short.get(n,"मूल CGL अभ्यास")}',data_page_link=f'p-{n}')
 out+='</div><div class="side-set" data-menu="sol"><h3>मूल प्रश्नों के समाधान</h3>'
 for n in range(31,34):out+=a(f'sol-{n}',f'पृ. {n} · {len(bynum[n]["input"]["questions"])} सवालों के हल',data_page_link=f'sol-{n}')
 out+='</div><div class="side-set" data-menu="pyq">'
 for u in bank:
  k=u['key'][5:];out+=a('pyq-'+k,labels[k]+' · '+str(len(u['input']['questions'])),data_page_link='pyq-'+k)
 return out+'</div><div class="smallside">'+a('refs','संदर्भ और स्रोत-नोट ↗',data_page_link='refs')+'</div></aside>'


def toolbar():
 def opt(label, options):
  return f'<optgroup label="{e(label)}">'+''.join(f'<option value="{id}">{e(t)}</option>' for id,t in options)+'</optgroup>'
 all=opt(MODES['study'],[(f'study-{n}',f'{n} · {t}') for n,t in short.items()])+opt(MODES['source'],[(f'p-{n}',f'मूल पृष्ठ {n}') for n in range(22,34)])+opt(MODES['sol'],[(f'sol-{n}',f'हल · मूल पृ. {n}') for n in range(31,34)])+'<option value="pyq">2026 PYQ</option><option value="refs">संदर्भ</option>'
 return f'<div class="toolbar screen-only needs-js" id="page-tools"><div class="jump"><label for="jump">पृष्ठ चुनें</label><select id="jump">{all}</select></div><div class="nextprev"><a href="#study-22" class="btn pale" id="prev">← पिछला</a><a href="#study-23" class="btn pale" id="next">अगला →</a></div></div>'


def head(print_mode):
 original_style=css(BASE,'typography.css')+css(BASE,'print.css')+css(BASE,'medieval.css')
 print_style=original_style+css(HERE,'study-print.css')
 screen_style=css(BASE,'typography.css')+css(BASE,'screen.css')+css(BASE,'medieval.css')+css(HERE,'study-screen.css')
 style=f'<style media="print">{print_style}</style>'+zoom
 if not print_mode:style+=f'<style media="screen">{screen_style}</style>'
 return f'<!doctype html><html lang="hi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#173c41"><meta name="author" content="Sonu Shakya"><meta name="description" content="मध्यकालीन इतिहास: 9 विस्तृत अध्ययन इकाइयाँ, मूल पृ. 22–33 का पूरा हिंदी अनुवाद और 90 प्रश्नों के हल।"><title>{TITLE}</title><style>{base.FONTSTYLE}</style>{style}</head>'


def site():
 top=f'''<a class="skip" href="#study-22">सीधे विस्तृत पाठ पर जाएँ</a><header class="mast screen-only"><div class="mast-inner wrap"><a class="brand" href="#home"><span class="mark">{brand_icon()}</span><span>मध्यकालीन इतिहास<em>SSC CGL · हिंदी अध्ययन</em></span></a><nav aria-label="मुख्य नेविगेशन">{tabnav()}</nav><span class="byline">Writer: Sonu Shakya</span></div></header>'''
 book=''.join(study(u) for u in theory)+''.join(original(u) for u in theory+practice)+''.join(solution(u) for u in practice)+bank_screen()+bibliography()
 return head(False)+f'<body>{base.LICENSE}{cover()}{top}{landing()}<div class="layout wrap" id="reader">{sidebar()}<main id="book">{toolbar()}<noscript><p class="noscript">स्क्रिप्ट बंद है। सभी खंड क्रम से नीचे पढ़ सकते हैं; ऊपर की विषय-सूची के लिंक भी काम करते हैं।</p></noscript>{book}</main></div><footer class="endbar screen-only wrap"><span>मध्यकालीन इतिहास · पृ. 22–33</span>{a("home","ऊपर जाएँ ↑")}<b>Writer: Sonu Shakya</b></footer><script>{css(HERE,"study.js")}</script></body></html>'


def printbook():
 b=''.join(study(u,True) for u in theory)+''.join(original(u,True) for u in theory+practice)+''.join(solution(u,True) for u in practice)+''.join(bank_group(u,True) for u in bank)+bibliography()
 return head(True)+f'<body class="curated">{base.LICENSE}{cover()}<main id="print-book">{b}</main></body></html>'

if __name__=='__main__':
 TMP.mkdir(parents=True,exist_ok=True);OUT.mkdir(parents=True,exist_ok=True)
 (OUT/'index.html').write_text(site(),encoding='utf-8'); (TMP/'print_work.html').write_text(printbook(),encoding='utf-8')
 print(f'Standalone HTML: {(OUT/"index.html").stat().st_size:,} bytes. {len(theory)} reading units, 12 complete source sheets, {QS+BQS} explained questions, {len(refs)} references.')
