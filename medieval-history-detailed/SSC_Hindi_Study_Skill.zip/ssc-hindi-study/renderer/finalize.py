"""Validate final PDF and publish only after the full original and both answer layers pass."""
from collections import Counter
from pathlib import Path
from hashlib import sha256
import json, os, re, unicodedata
import pymupdf as f

P=Path(__file__).resolve().parent.parent
OUT=Path(os.environ.get('STUDY_OUT',P/'medieval-history-detailed')).resolve()
CASE=Path(os.environ.get('STUDY_CASE',P/'skills/ssc-hindi-study/.case-medieval')).resolve()
TMP=Path(os.environ.get('STUDY_TMP','/tmp/medieval-study'))
NAME='SSC_CGL_Medieval_History_Hindi_Detailed.pdf'
DEST=OUT/NAME
author='Sonu Shakya'
U=json.loads((CASE/'compiled.json').read_text(encoding='utf-8'))['units']
REPORT=json.loads((TMP/'layout.json').read_text(encoding='utf-8'))['report']
UNITS={u['key']:u for u in U}
bank={q['n']:q for u in U if u['mode']=='bank' for q in u['input']['questions']}
answers={f'ans-{q["page"]}-{q["id"].replace("/","-")}':q for u in U if u['mode']=='practice' for q in u['input']['questions']}
pages={u['input']['source']['n']:u for u in U if u['mode']!='bank'}
starts={key:i for i,r in enumerate(REPORT) for key in r['units']}
want={f'study-{n}' for n in range(22,31)}|{f'p-{n}' for n in pages}|{f'sol-{n}' for n in range(31,34)}|{'pyq-'+u['key'][5:] for u in U if u['mode']=='bank'}|{'refs'}
MONTH={'Sep':'सितंबर','Oct':'अक्टूबर'}


def compact(text):
 s=unicodedata.normalize('NFD',text)
 return re.sub(r'\s|\u200b|\u200c|\u200d','',re.sub(r'([\u093a-\u094d\u0900-\u0903\u0951-\u0957])\1+',r'\1',s))


def cover_links(doc):
 links=[x for x in doc[0].get_links() if 'nameddest' in x]
 result={l['nameddest']:l for l in links}
 assert set(result)==want,(len(result),set(result)^want)
 assert all(l['page']==starts[l['nameddest']] for l in links)
 return result


def outline_at(doc,by,key,title,level):
 l=by[key]; i=l['page']; y=doc[i].rect.height-l['to'].y
 return [level,title,i+1,max(5.0,y)]


def validate(doc, native=False):
 assert len(doc)==len(REPORT)==52
 assert len({im[0] for pg in doc for im in pg.get_images()})==9
 if not native:cover_links(doc)
 assert all(abs(pg.rect.width-595)<.25 and abs(pg.rect.height-842)<.25 for pg in doc)
 ts=[p.get_text() for p in doc];whole='\n'.join(ts)
 for pattern,c in [(r'क्यों:',90),(r'विकल्पों में फर्क:',90),(r'पुस्तक की कुंजी\s*\([a-d]\)',48),(r'संकलन की कुंजी\s*[A-D]\s*·',42),(r'PDF पृ\.',42),(r'स्कैन का PDF पृष्ठ',12)]:assert len(re.findall(pattern,whole))==c,(pattern,c,len(re.findall(pattern,whole)))
 ids=[int(i) for i in re.findall(r'\bID\s+(\d+)\b',whole)];assert Counter(ids)==Counter(bank.keys())
 if native:return
 assert doc.metadata['author']==author
 assert 'true' in doc.xref_get_key(doc.pdf_catalog(),'MarkInfo')[1]
 links=[x for pg in doc for x in pg.get_links() if x.get('nameddest')]
 assert all(0<=x.get('page',-1)<len(doc) for x in links)
 assert len({l['nameddest'] for l in links if l['nameddest'].startswith('old-')})==48
 assert any('Devanagari' in str(font) for font in doc[1].get_fonts())
 by_kind=Counter()
 for index,(page,text,r) in enumerate(zip(doc,ts,REPORT)):
  by_kind[r['kind']]+=1; assert 'Writer: Sonu Shakya' in text
  assert len(text)>950 and sum(c in 'कखगघङचछजझटठडढतथदधनपफबभमयरलवशषसह' for c in text)>180,index+1
  if r['kind']=='source':
   n=int(r['units'][0].split('-')[1]);u=pages[n];ci=compact(text)
   assert compact(f'स्कैन का PDF पृष्ठ {n+4}') in ci
   if u['mode']=='practice':
    qs=u['input']['questions'];keys=[a for a in u['input']['source']['lines'] if a[0]=='K']; c=sum(len(k)-2 for k in keys)+len(qs)*4
    assert len(re.findall(r'\([a-d]\)',text))==c,(n,c)
    for k in keys:assert compact(''.join(k[2:])) in ci,(n,k)
  elif r['kind']=='study':
   ci=compact(text)
   for atom in r['atoms']:
    _,n,i=atom.split('-'); sec=pages[int(n)]['sections'][int(i)-1];s=compact(sec['title']);assert s in ci,(index+1,sec['title'])
  elif r['kind']=='solution':
   assert len(re.findall(r'पुस्तक की कुंजी\s*\(([a-d])\)',text))==len(r['atoms']),index+1
   assert re.findall(r'पुस्तक की कुंजी\s*\(([a-d])\)',text)==[answers[i]['key'] for i in r['atoms']],index+1
  elif r['kind']=='bank':
   matches=list(re.finditer(r'प्र\.\s+(\d+)\s*·\s*ID\s+(\d+)\b',text));assert len(matches)==len(r['atoms']),index+1
   for j,m in enumerate(matches):
    serial,ident=map(int,m.groups());q=bank[ident];assert serial==q['serial'] and 'q-'+str(ident)==r['atoms'][j];t=text[m.end():matches[j+1].start() if j<len(matches)-1 else len(text)]; d,mon,y,s=re.search(r'(\d+) (Sep|Oct) (\d{4}) - Shift (\d+)',q['shift_title']).groups()
    assert compact(f'{int(d)} {MONTH[mon]} {y} · शिफ़्ट {s} · PDF पृ. {q["p"]}') in compact(t),ident
    assert re.findall(r'^([A-D])\.\s',t,re.M)==list('ABCD'),ident
    assert re.search(fr'संकलन की कुंजी\s*{q["key"]}\s*·',t) and 'क्यों:' in t and 'विकल्पों में फर्क:' in t,ident
 return by_kind


with f.open(TMP/'study-raw.pdf') as d:
 assert len(d)==len(REPORT)
 by=cover_links(d)
 meta=d.metadata;meta.update(author=author,title='SSC CGL · मध्यकालीन इतिहास — विस्तृत हिंदी अध्ययन संस्करण',subject='मूल पृ. 22–33 के अनुवाद और 90 व्याख्यायुक्त प्रश्न; अलग विस्तृत पाठ, मूल अभ्यास और 2026 PYQ',keywords='SSC CGL, Medieval History, Hindi study edition, Sonu Shakya, 2026 PYQ');d.set_metadata(meta)
 toc=[[1,'विषय-सूची',1]]
 toc.append(outline_at(d,by,'study-22','01 · विस्तृत अध्ययन',1));toc.extend(outline_at(d,by,f'study-{n}',f'मूल पृ. {n} · {pages[n]["title"]}',2) for n in range(22,31))
 toc.append(outline_at(d,by,'p-22','02 · मूल अनुवाद एवं अभ्यास',1));toc.extend(outline_at(d,by,f'p-{n}',f'पृ. {n} · {pages[n]["input"]["source"]["title"]}',2) for n in range(22,34))
 toc.append(outline_at(d,by,'sol-31','03 · मूल अभ्यास के समाधान',1));toc.extend(outline_at(d,by,f'sol-{n}',f'पृ. {n} के हल',2) for n in range(31,34))
 toc.append(outline_at(d,by,'pyq-delhi','04 · 2026 PYQ · व्याख्या सहित',1));toc.extend(outline_at(d,by,'pyq-'+u['key'][5:],u['title'],2) for u in U if u['mode']=='bank')
 toc.append(outline_at(d,by,'refs','05 · संदर्भ',1));d.set_toc(toc,collapse=1)
 temp=DEST.with_suffix('.tmp.pdf'); d.save(temp,garbage=3,deflate=True,clean=False)
with f.open(temp) as d:
 groups=validate(d)
 assert len(d.get_toc())==len(toc)==35
with f.open(TMP/'proof/site-print.pdf') as d:validate(d,native=True)
temp.replace(DEST)
print('PASS:',NAME,'|',dict(groups),'| 30 linked TOC targets, 35 bookmarks, 9 source images, selectable Hindi')
print('PASS: 48 original keys and 42 compilation keys, 90 explanations, 42 serials/IDs and date/shift/page; native print complete.')
for p in (DEST, OUT/'index.html'):print(f'{sha256(p.read_bytes()).hexdigest()}  {p.name}  {p.stat().st_size:,} bytes')
