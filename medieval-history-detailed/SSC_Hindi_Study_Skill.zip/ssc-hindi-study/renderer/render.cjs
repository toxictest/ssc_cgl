const fs=require('node:fs'), url=require('node:url'), path=require('node:path');
const {chromium}=require(process.env.PLAYWRIGHT_CORE||'playwright-core');
const d=process.env.STUDY_TMP||'/tmp/medieval-study';
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM || undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking']});
 try{
  const page=await browser.newPage({viewport:{width:719,height:1040},deviceScaleFactor:1});
  await page.emulateMedia({media:'print'});
  await page.goto(url.pathToFileURL(path.join(d,'print_work.html')).href,{waitUntil:'load'});
  await page.evaluate(()=>document.fonts.ready);
  const plan=await page.evaluate(()=>{
   const limit=1019;
   document.body.style.width='190mm';
   const main=document.getElementById('print-book');
   const rect=el=>el.getBoundingClientRect().height;
   const outer=el=>rect(el)+parseFloat(getComputedStyle(el).marginBottom||0);
   const physical=()=>{const el=document.createElement('div');el.className='pdf-page';return el;};
   const cover=document.querySelector('.cover');
   if(rect(cover)>limit)throw Error('Cover overflow: '+rect(cover));
   const initial=[...main.children];
   const report=[{kind:'cover',h:Math.round(rect(cover)),units:['toc'],atoms:[]}];
   function shell(src,cont){
    const el=src.cloneNode(false), h=src.querySelector(':scope>[data-unit-head]').cloneNode(true), body=src.querySelector('[data-unit-body]').cloneNode(false), foot=src.querySelector(':scope>.reader-foot').cloneNode(true);
    if(cont){el.id+='-cont-'+cont;h.classList.add('cont-head');h.querySelector('.kicker').textContent+=' · जारी';}
    el.append(h,body,foot);return {el,body};
   }
   function paginated(batch,kind){
    let flat=[],srcs=[];
    for(const src of batch){
     const x=srcs.length,start=flat.length,body=src.querySelector('[data-unit-body]'); let prefix=[0];
     const atoms=[...body.children];
     if(!atoms.every(a=>a.hasAttribute('data-atom')))throw Error(`Broken atoms ${src.id}`);
     const pad=[0,1].map(cont=>{const {el}=shell(src,cont);main.append(el);const h=rect(el);el.remove();return h;});
     atoms.forEach((atom,i)=>{prefix.push(prefix.at(-1)+outer(atom));flat.push({x,i});});
     srcs.push({src,pad,prefix,atoms,start,end:flat.length});
    }
    const N=flat.length,rows=[];
    function segment(a,b){
     const chunks=[];let h=0;
     for(const s of srcs){
      let i=Math.max(0,a-s.start),j=Math.min(s.atoms.length,b-s.start);if(i>=j)continue;
      h+=s.pad[Number(i>0)]+s.prefix[j]-s.prefix[i];if(chunks.length)h+=12;
      chunks.push({id:s.src.id,src:s.src,atoms:s.atoms.slice(i,j),from:i,to:j});
     }
     return {a,b,h,chunks};
    }
    const lookup=new Map();
    function window(a,b){const k=a+','+b;if(!lookup.has(k))lookup.set(k,segment(a,b));return lookup.get(k);}
    const memo=new Map();
    function best(a){
     if(a===N)return {n:0,cost:0,path:[]};if(memo.has(a))return memo.get(a);
     let winner=null;
     for(let b=a+1;b<=N;b++){
      const w=window(a,b);if(w.h>limit-4)break;
      const rest=best(b);if(!rest)continue;
      const cost=(limit-w.h)**2+rest.cost+1600*Math.max(0,w.chunks.length-1);
      const r={n:rest.n+1,cost,path:[w,...rest.path]};
      if(!winner||r.n<winner.n||r.n===winner.n&&r.cost<winner.cost)winner=r;
     }
     memo.set(a,winner);return winner;
    }
    const sol=best(0);
    if(!sol)throw Error(`Cannot fit standalone ${kind} atoms: ${JSON.stringify(srcs.map(s=>[s.src.id,s.pad,s.prefix]))}`);
    for(const w of sol.path){
     const pg=physical(), ids=[], atoms=[];
     pg.dataset.kind=kind;
     for(let k=0;k<w.chunks.length;k++){
      const x=w.chunks[k], item=shell(x.src,x.from);
      if(k)item.el.style.marginTop='12px';
      pg.append(item.el);for(const a of x.atoms){item.body.append(a);atoms.push(a.id);}
      ids.push(item.el.id);
     }
     main.insertBefore(pg,batch[0]);const h=rect(pg);if(h>limit+1)throw Error(`Page overflow ${ids.join(' ')} ${h}`);
     report.push({kind,h:Math.round(h),units:ids,atoms});
    }
    batch.forEach(b=>b.remove());
   }
   let i=0;
   while(i<initial.length){
    const el=initial[i], part=el.dataset.partition;
    if(part){const batch=[el];while(initial[i+1]?.dataset.partition===part)batch.push(initial[++i]);paginated(batch,part);}
    else{
     const pg=physical();const kind=el.hasAttribute('data-original')?'source':'refs';pg.dataset.kind=kind;main.insertBefore(pg,el);pg.append(el);
     const h=rect(pg);if(h>limit+1)throw Error(`${el.id} too tall: ${h}`);
     report.push({kind,h:Math.round(h),units:[el.id],atoms:[]});
    }i++;
   }
   const map=new Map(report.flatMap((row,i)=>row.units.map(id=>[id,i+1])));
   for(const a of cover.querySelectorAll('.cover-toc a[href^="#"]')){
    const folio=map.get(a.getAttribute('href').slice(1));if(!folio)throw Error('Missing folio '+a.href);
    const g=document.createElement('span');g.className='toc-folio';g.textContent='PDF '+folio;
    const cell=a.closest('li')||a;
    cell.append(g);
   }
   report[0].h=Math.round(rect(cover));if(report[0].h>limit)throw Error('Cover overflow after folios: '+report[0].h);
   const cts={original:document.querySelectorAll('[data-original]').length,old:document.querySelectorAll('[data-old-n]').length,solutions:document.querySelectorAll('[data-solution]').length,pyq:document.querySelectorAll('[data-qid]').length,img:[...document.images].filter(i=>i.complete&&i.naturalWidth).length,notes:document.querySelectorAll('.note-block').length};
   if(JSON.stringify(cts)!==JSON.stringify({original:12,old:48,solutions:48,pyq:42,img:9,notes:46}))throw Error(JSON.stringify(cts));
   const ids=[...document.querySelectorAll('[id]')].map(e=>e.id);if(new Set(ids).size!==ids.length)throw Error('Duplicate IDs in print book');
   const bad=[...document.querySelectorAll('a[href^="#"]')].filter(a=>!document.getElementById(a.getAttribute('href').slice(1)));
   if(bad.length)throw Error('Bad print targets '+bad.map(a=>a.href));
   const wide=[...document.querySelectorAll('.readerSheet,.sheet,.vb-card,.vb-figure,.note-block,.answer-card,.bank-card,.cover')].filter(el=>el.scrollWidth>el.clientWidth+3);
   if(wide.length)throw Error('Horizontal overflow '+wide.map(e=>`${e.id} ${e.textContent.slice(0,30)}`));
   return {report,cts};
  });
  fs.writeFileSync(d+'/layout.json',JSON.stringify(plan,null,2));
  const summary=plan.report.reduce((o,x)=>(o[x.kind]=(o[x.kind]||0)+1,o),{});
  console.log(JSON.stringify({pages:plan.report.length,summary,heights:plan.report.map(x=>x.h),...plan.cts}));
  const header='<div style="width:100%;display:flex;justify-content:space-between;align-items:center;margin:0 10mm;padding:0 0 1.4mm;font:700 7.5pt Arial;color:#164b44;border-bottom:.22mm solid #c6d8cf;letter-spacing:.16pt"><span>SSC CGL &nbsp; / &nbsp; MEDIEVAL HISTORY</span><span>Writer: Sonu Shakya</span></div>';
  const footer='<div style="width:100%;display:flex;justify-content:space-between;align-items:center;margin:0 10mm;padding:1.45mm 0 0;font:7pt Arial;color:#48695c;border-top:.21mm solid #cfddd3"><span>SSC CGL &nbsp; / &nbsp; HINDI STUDY EDITION</span><span>PDF &nbsp; <span class="pageNumber"></span> / <span class="totalPages"></span></span></div>';
  await page.pdf({path:d+'/study-raw.pdf',preferCSSPageSize:true,printBackground:true,displayHeaderFooter:true,headerTemplate:header,footerTemplate:footer,tagged:true,outline:true,timeout:60000});
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
