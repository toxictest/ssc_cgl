const fs=require('node:fs'),path=require('node:path'),url=require('node:url');
const {chromium}=require(process.env.PLAYWRIGHT_CORE||'playwright-core');
const root=path.dirname(__dirname),out=path.join(process.env.STUDY_OUT||path.join(root,'medieval-history-detailed'),'index.html'),purl=url.pathToFileURL(out).href;
const units=JSON.parse(fs.readFileSync(path.join(process.env.STUDY_CASE||path.join(root,'skills/ssc-hindi-study/.case-medieval'),'compiled.json'),'utf8')).units;
const proof=(process.env.STUDY_TMP||'/tmp/medieval-study')+'/proof';fs.mkdirSync(proof,{recursive:true});
const assert=(x,m)=>{if(!x)throw Error(m);};const eq=(a,b,m)=>assert(a===b,`${m}: ${a} !== ${b}`);
(async()=>{
 const b=await chromium.launch({executablePath:process.env.CHROMIUM || undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking']});
 const req=[],errs=[];const events=p=>{p.on('request',r=>{if(/^https?:/.test(r.url()))req.push(r.url());});p.on('pageerror',e=>errs.push(e.message));};
 const go=async(p,id)=>{await p.evaluate(k=>{location.hash=k;},id);await p.waitForFunction(k=>!!document.getElementById(k)?.getBoundingClientRect().height,id);};
 try{
  const ctx=await b.newContext({viewport:{width:1440,height:1060},offline:true});const p=await ctx.newPage();events(p);
  await p.goto(purl,{waitUntil:'load'});await p.evaluate(()=>document.fonts.ready);
  const errors=await p.evaluate(us=>{
   const out=[],Q=(s,el=document)=>el?.querySelector(s), A=(s,el=document)=>[...(el?.querySelectorAll(s)||[])], $=s=>document.getElementById(s),check=(x,s)=>{if(!x)out.push(s);};
   const txt=s=>(s||'').normalize('NFC').replace(/\s+/g,' ').trim();
   const count=(s,n)=>check(A(s).length===n,'count '+s+'='+A(s).length+' wanted '+n);
   for(const [s,n] of [['.source-sheet',12],['.vb-figure',17],['.vb-brace',6],['.vb-table',4],['.vb-table tbody tr',26],['img.sourcephoto',9],['.note-block',46],['[data-solution]',48],['[data-qid]',42],['.vb-key',5],['.old-q-locator',40],['.readerSheet.study-sheet',9],['[data-pyq-group]',5]])count(s,n);
   check(document.fonts.check('400 18px "Noto Hindi"','मध्यकालीन'), 'Hindi font');
   const ids=A('[id]').map(e=>e.id);check(new Set(ids).size===ids.length,'duplicate ids');
   for(const a of A('a[href^="#"]'))check(a.getAttribute('href')==='#'||$(a.getAttribute('href').slice(1)), 'missing target '+a.getAttribute('href'));
   check(A('img').every(x=>x.naturalWidth&&x.src.startsWith('data:')),'embed');
   for(const u of us){
    if(u.mode!=='bank'){
     const src=u.input.source, n=src.n, el=$('p-'+n), content=txt(Q('.papercontent',el)?.textContent);
     for(const [op,...r] of src.lines){
      let vs=op==='F'?[r[0],...r.slice(2)]:op==='V'?r.slice(1):r;
      if(['X','Y','@','M','Q'].includes(op))continue;
      for(const raw of vs)for(const s of raw.split('~')){const t=txt(s.replace(/^>/,'').replace('^',': '));if(t)check(content.includes(t),`p${n}: ${t}`);}
     }
     if(u.mode==='theory'){
      const sheet=$('study-'+n);
      check(txt(Q('.intro',sheet)?.textContent)===txt(u.intro),'intro '+n);
      u.sections.forEach((s,i)=>{
       const el=$(`s-${n}-${i+1}`);check(el?.dataset.anchorLines===s.lines.join(','),'anchors '+n+'/'+i);check(Q('h3',el)?.textContent===s.title,'section '+n+'/'+i);
       const v=txt(el?.textContent);
       for(const [op,...r] of s.body)for(const item of r)check(v.includes(txt(item)),`study ${n}/${i} missing ${item.slice(0,28)}`);
      });
     }else{
      for(const q of u.input.questions){
       const id=n+'-'+q.id.replace('/','-');const el=$('old-'+id), answer=$('ans-'+id);const s=u.solutions[q.id];
       check(txt(Q('.old-q-stem',el)?.textContent)===txt(q.question.split('~')[0]),'old stem '+id);
       check(A('.old-options li>b',el).map(t=>t.textContent).join('')===[...q.letters].map(l=>`(${l})`).join(''),'old option letters '+id);
       check(A('.old-options li>span',el).every((a,i)=>a.textContent===q.options[i]),'old option texts '+id);
       const date=q.stamp?`SSC CGL (टियर-${q.stamp.split(' ').join(') ')}`:'';
       check((Q('.old-q-locator',el)?.textContent||'')===date,'old date '+id);
       check(Q('.key-label',answer)?.textContent.includes(`(${q.key}) · ${q.valid_option}`),'old key '+id);
       check(Q('.reason',answer)?.textContent.includes(s.why)&&Q('.compare',answer)?.textContent.includes(s.compare),'old explanation '+id);
       if(s.caution)check(Q('.answer-caution',answer)?.textContent.includes(s.caution.text),'old caution '+id);
      }
     }
    }else{
     const rows=A('[data-qid]', $('pyq-'+u.key.slice(5)));
     check(rows.map(row=>+row.dataset.qid).join(',')===u.input.questions.map(q=>q.n).join(','),'PYQ sequence '+u.key);
     const mon={Sep:'सितंबर',Oct:'अक्टूबर'};
     for(const q of u.input.questions){
      const el=$('q-'+q.n), sol=u.solutions[q.n], t=Q('h3',el); const stem=[...t.childNodes].flatMap(n=>n.nodeType===3?[n.textContent]:[...n.children].map(a=>a.textContent)).join(' ');
      check(txt(stem)===txt(q.question),'bank stem '+q.n);
      check(A('.bank-options b',el).map(a=>a.textContent).join('')==='A.B.C.D.'&&A('.bank-options li span',el).every((a,i)=>a.textContent===q.options[i]),'bank opts '+q.n);
      const m=q.shift_title.match(/(\d+) (Sep|Oct) (\d+) - Shift (\d+)$/);
      check(el.dataset.serial==q.serial && Q('.q-strip span+span',el).textContent===`${+m[1]} ${mon[m[2]]} ${m[3]} · शिफ़्ट ${m[4]} · PDF पृ. ${q.p}`,'bank locator '+q.n);
      check(el.dataset.key===q.key && Q('.key-label',el).textContent.includes(`${q.key} · ${q.options['ABCD'.indexOf(q.key)]}`),'bank key '+q.n);
      check(Q('.reason',el).textContent.includes(sol.why)&&Q('.compare',el).textContent.includes(sol.compare),'bank explanation '+q.n);
      if(sol.caution)check(Q('.answer-caution',el)?.textContent.includes(sol.caution.text),'bank caution '+q.n);
     }
    }
   }
   return out;
  },units);
  assert(!errors.length,JSON.stringify(errors));
  eq(await p.locator('[data-sheet]:visible').count(),1,'Single sheet at start');eq(await p.locator('#study-22').isVisible(),true,'Study is default');
  eq(await p.locator('.byline').textContent(),'Writer: Sonu Shakya','User credit');
  await p.screenshot({path:proof+'/web-home.png'});
  await p.locator('#next').click();await p.waitForFunction(()=>document.querySelector('#study-23').offsetWidth>0);
  await p.locator('[data-tab="source"]').click();await p.waitForFunction(()=>document.querySelector('#p-22').offsetWidth>0);
  await p.locator('[data-tab="sol"]').click();await p.waitForFunction(()=>document.querySelector('#sol-31').offsetWidth>0);
  await p.locator('#ans-31-delhi-3 a[href="#old-31-delhi-3"]').click();await p.waitForFunction(()=>document.querySelector('#old-31-delhi-3').offsetWidth>0);
  await p.locator('[data-tab="pyq"]').click();await p.waitForFunction(()=>document.querySelector('#pyq').offsetWidth>0);
  eq(await p.locator('[data-qid]:visible').count(),42,'All PYQ');
  await p.locator('[data-filter="deccan"]').click();eq(await p.locator('[data-qid]:visible').count(),5,'Topic filter');
  await p.locator('#find').fill('631');eq(await p.locator('[data-qid]:visible').count(),1,'Find ID');
  eq(await p.locator('#q-631 .reason').isVisible(),false,'Collapsed explanation');
  await p.locator('#open-keys').click();eq(await p.locator('#q-631 .reason').isVisible(),true,'Explanation shown');
  eq(await p.locator('#q-631 .answer-caution').isVisible(),true,'Dedicated historical caveat');
  await p.locator('#q-631 .q-strip').scrollIntoViewIfNeeded();await p.screenshot({path:proof+'/web-pyq.png'});
  await p.locator('#find').fill('no-match-8-000');eq(await p.locator('#open-keys').isDisabled(),true,'No results');
  await p.emulateMedia({media:'print'});eq(await p.locator('.source-sheet:visible').count(),12,'Print includes all source');eq(await p.locator('[data-qid]:visible').count(),42,'Print clears filter');
  eq(await p.locator('[data-solution]:visible').count(),48,'Print includes all original solutions');
  await p.pdf({path:proof+'/site-print.pdf',preferCSSPageSize:true,printBackground:true});
  await p.emulateMedia({media:'screen'});
  for(const [frag,sheet] of [['q-4339','pyq'],['s-27-3','study-27'],['ans-32-faith-4','sol-32'],['chapter-2','p-24'],['ref-taj','refs']]){
   await p.goto(purl+'#'+frag,{waitUntil:'load'});await p.waitForFunction(i=>document.getElementById(i).offsetWidth>0,frag);
   eq(await p.locator('[data-sheet]:visible').getAttribute('id'),sheet,'Fresh deep link '+frag);
  }
  for(const width of [320,390,768,1024,1440]){
   const c=await b.newContext({viewport:{width,height:880},deviceScaleFactor:1,isMobile:width<768,hasTouch:width<768,offline:true});const m=await c.newPage();events(m);
   await m.goto(purl);await m.evaluate(()=>document.fonts.ready);
   const ids=await m.locator('[data-sheet]').evaluateAll(els=>els.map(e=>e.id));
   for(const id of ids){await go(m,id);const [w,doc]=await m.evaluate(()=>[innerWidth,document.documentElement.scrollWidth]);eq(Math.max(w,doc),w,`Viewport ${width} · ${id}`);}
   if(width===390){await m.goto(purl);await m.screenshot({path:proof+'/web-mobile.png'});await go(m,'s-27-3');await m.locator('#s-27-3').screenshot({path:proof+'/web-mobile-table.png'});}
   await c.close();
  }
  const nojs=await b.newContext({javaScriptEnabled:false,offline:true});const n=await nojs.newPage();events(n);await n.goto(purl);
  eq(await n.locator('[data-sheet]:visible').count(),26,'No-JS content');await n.locator('#q-631 summary').click();eq(await n.locator('#q-631 .worked').isVisible(),true,'No-JS question answer');
  eq(errs.length,0,'JS errors');eq(req.length,0,'External requests');
  console.log('PASS: original data, all 46 detailed sections, all 90 explanations and comparison lines, 42 keys/locators; links, offline, fallback, responsive widths 320/390/768/1024/1440 and print.');
 }finally{await b.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
