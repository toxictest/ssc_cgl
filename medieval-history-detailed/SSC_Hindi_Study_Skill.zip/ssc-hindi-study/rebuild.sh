#!/bin/sh
# Rebuild the *reviewed Medieval example*. The skill runner itself is chapter-independent.
set -eu
ROOT=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
case ${1:---all} in
  --all) html_only=0;;
  --html) html_only=1;;
  *) printf 'Usage: %s [--all | --html]\n' "$0" >&2; exit 2;;
esac
export STUDY_CASE="$ROOT/examples/medieval-case"
export STUDY_CORE="$ROOT/renderer/core"
export STUDY_OUT="${STUDY_OUT:-$ROOT/exports}"
if [ -z "${STUDY_TMP:-}" ]; then
  STUDY_TMP=$(mktemp -d "${TMPDIR:-/tmp}/ssc-hindi-study.XXXXXXXX")
  trap 'rm -rf -- "$STUDY_TMP"' EXIT
fi
export STUDY_TMP
"${PYTHON:-python}" "$ROOT/renderer/build_study.py"
if [ "$html_only" -eq 0 ]; then
  node "$ROOT/renderer/render.cjs"
  node "$ROOT/renderer/qa.cjs"
  "${PYTHON:-python}" "$ROOT/renderer/finalize.py"
fi
printf '\nOutput: %s\n' "$STUDY_OUT"
