# Manifest and unit formats

Paths in a manifest are relative to the manifest. `physical_offset` means **physical PDF page − printed page**, using one-based page numbers. Use `null` for the two bank paths if not supplied. `references` is a JSON object keyed by a stable short ASCII name, with each value `{"title":"…", "url":"https://…"}`. `references` may be omitted for a source-only study edition. Save text as UTF-8. Blank lines are ignored. `|` is a separator and must not appear in prose.

## Original-data/<printed page>.txt

First row: `#|printed page|Hindi title|topic-slug|chapter number`.
Theory rows: `H/J/A/P` for headings or paragraph, `B|title|bullet|…`, `V|image-id|title|bullet|…`, `R|title|bullet|…`, `M|image-id|alt`, `F|title|diagram-shape|node|…`, `T|title|column name|…` followed by `-|cell|…` or `=|spanning heading`, `O|item|…`. `@` optionally opens a grid with widths, or closes one without widths. Within content use `label^meaning`, `~` for sub-lines in diagrams/tables, `>` for a sub-bullet. Scan line references check the physical line numbers in these files, including the header and grid lines, so re-prepare a unit after edits.

Practice rows: `S|topic title` (or `S|topic title|slug`), `Q|number|I 2025|question|option a|option b|option c|option d` (optional last field of letters, e.g. `acbd`; exam tag can be blank). `X` and `Y` optionally mark column breaks. `K|उत्तरमाला|1. (d)|2. (a)|…` keys the preceding topic, which can cross a page boundary. Questions use `ascii-topic-slug/number` as the solution ID (prepare gives the exact IDs).

## notes/p-22.txt (theory)

```
!|Title for this study unit|What the learner should understand
H|Section title|2,4-7|reference1,reference2
P|An explanatory paragraph (not a copied source bullet).
D|Term|Definition and, if useful, an example
B|A point to compare
T|Column 1|Column 2
-|Value 1|Value 2
K|Exam clue|What to look for in the question
C|Source distinction|State which text says what, and any uncertainty.
```

One `H` per section. `C` claims should have primary or reliable secondary references in that section's reference list if a factual correction is being made; uncertainty can be explicitly flagged. Assign every substantive original line shown by `prepare` to a section. It is fine to group related lines. `T` rows should be relatively short, and can be followed by `P/D/B/K/C`.

## notes/p-31.txt (practice) or notes/bank-delhi.txt (PYQ)

```
!|Unit title|Unit context or a way to use the questions
A|delhi/1|Why the keyed option answers the exact stem.|Explain the most relevant alternative or an exam trap.|reference1,reference2
C|delhi/1|Optional claim or answer-key caution, clearly separate.|reference1
```

Use numeric IDs rather than topic/number for PYQs. The refs field is optional; don't insert empty pipes before the grounds or comparison. Keep all `A` rows in source order. The runner resolves option text and correct letter from the original K row / bank key; do not retype them into an answer field. A `C` row may follow its `A` once. Notes can say the key is imperfect without overwriting it.

## Bank JSON

An array of topic objects `{id, title, items}`. Each item carries `{n, serial, p, shift_title, question, options, key}`. `n` is the unique text-layer ID and `serial` is the visible printed question number (may be the same). `p` is a one-based physical PDF page. `shift_title` records the source date and shift. `options` has four strings; `key` is one uppercase Latin letter, A–D. Additional source fields (e.g. an existing `why`) are retained. If the PDF is not provided, the project cannot claim a manual PDF comparison.

## Run record

`prepare` creates a witness folder under `scratch`, with input digests. `check --reviewed` explicitly attests to manual comparison and writes a validated unit to `checked`. `assemble` checks every approval against the current input and notes, and exports compiled data and a portable coverage report. The script validates structure and source attachment, not the truth of prose.
